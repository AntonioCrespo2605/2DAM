package com.example.patronosaurio;

import androidx.appcompat.app.AppCompatActivity;


import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class School extends AppCompatActivity {
    boolean fondoActivado=false;
    int contPasar=0;

    ImageView cruella;
    ImageView cabezaRick;
    ImageView fondo;
    ImageView cuadroTexto1;
    TextView dialogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school);

        cruella=findViewById(R.id.cruella);
        cabezaRick=findViewById(R.id.cabezarick);
        fondo=findViewById(R.id.fondo);
        cuadroTexto1=findViewById(R.id.cuadrotexto1);
        dialogo = findViewById(R.id.dialogo);

        cruella.setVisibility(View.INVISIBLE);
        cabezaRick.setVisibility(View.INVISIBLE);
        cuadroTexto1.setVisibility(View.INVISIBLE);
        dialogo.setText("");
        fondo.setBackgroundResource(R.drawable.darkclass);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                cabezaRick.setVisibility(View.VISIBLE);
                cuadroTexto1.setVisibility(View.VISIBLE);
                fondo.setImageDrawable(getDrawable(R.drawable.darkclass));
                dialogo.setText("...y por eso los glúteos de los babuínos no tienen pelo... ");
                fondoActivado=true;
            }
        }, 2000);


        //al clicar en el fondo
        fondo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fondoActivado){
                    switch(contPasar){
                        case 0:narrador1();
                            break;
                        case 1:imagenDirectoraPuerta();
                            break;
                        case 2:dialogoDirectora1();
                            break;
                        case 3:dialogoDirectora2();
                            break;
                        case 4:
                            break;
                        case 5:
                            break;
                    }
                    contPasar++;
                }
            }
        });

    }

    private void narrador1(){
        cabezaRick.setVisibility(View.INVISIBLE);
        dialogo.setTypeface(null, Typeface.BOLD_ITALIC);
        dialogo.setText("De pronto la malvada directora del colegio \nentra por la puerta de clase");
    }

    private void imagenDirectoraPuerta(){
        dialogo.setTypeface(null, Typeface.NORMAL);
        dialogo.setText("");
        cuadroTexto1.setVisibility(View.INVISIBLE);
        fondo.setImageDrawable(getDrawable(R.drawable.puerta));
        fondo.setBackgroundResource(R.drawable.gris);
        cruella.setVisibility(View.VISIBLE);
    }

    private void dialogoDirectora1(){
        dialogo.setText("bbbbbbbbbb");
    }

    private void dialogoDirectora2(){
        dialogo.setText("ccccccccccccccc");
    }



}