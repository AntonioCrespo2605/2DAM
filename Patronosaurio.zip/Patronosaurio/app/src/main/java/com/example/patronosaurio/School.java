package com.example.patronosaurio;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class School extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school);

        ImageView cabezaRick=findViewById(R.id.cabezarick);
        ImageView fondo=findViewById(R.id.fondo);
        ImageView cuadroTexto1=findViewById(R.id.cuadrotexto1);
        TextView dialogo = findViewById(R.id.dialogo);

        cabezaRick.setVisibility(View.INVISIBLE);
        cuadroTexto1.setVisibility(View.INVISIBLE);
        dialogo.setText("");
        fondo.setBackgroundResource(R.drawable.darkclass);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                cabezaRick.setVisibility(View.VISIBLE);
                cuadroTexto1.setVisibility(View.VISIBLE);
                fondo.setImageDrawable(getDrawable(R.drawable.darkclass));
                dialogo.setText("...y por eso los glúteos de los babuínos no tienen pelo... ");
            }
        }, 2000);




    }
}