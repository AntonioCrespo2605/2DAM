package com.example.fotomaton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Foto extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{

    public static final int  CAMERA_ACTION_CODE=1;

    EditText titulo;
    ImageView camara, calendario, galeria, foto, salir;
    TextView fecha;
    Bitmap finalPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);

        getSupportActionBar().hide();

        //comprobamos los permisos de camara
        checkCameraPermission();

        //declaración de componentes
        titulo=findViewById(R.id.titulo);
        camara=findViewById(R.id.camara);
        calendario=findViewById(R.id.calendario);
        galeria=findViewById(R.id.galeria);
        foto=findViewById(R.id.foto);
        salir=findViewById(R.id.salir);
        fecha=findViewById(R.id.fecha);

        //mientras no exista foto ocultamos algunos componentes
        calendario.setVisibility(View.INVISIBLE);
        galeria.setVisibility(View.INVISIBLE);
        titulo.setVisibility(View.INVISIBLE);
        fecha.setVisibility(View.INVISIBLE);

        //boton de salir
        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //boton de camara
        camara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(intent.resolveActivity(getPackageManager())!=null){
                    startActivityForResult(intent, CAMERA_ACTION_CODE);
                }else{
                    Toast.makeText(Foto.this, "There is no app that support this action", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //boton galeria
        galeria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Foto.this, "Saved on gallery", Toast.LENGTH_SHORT).show();
                String nombre = titulo.getText().toString();
                saveImageInGallery(finalPhoto, nombre, fecha.getText().toString());
            }
        });

        //boton calendario
        calendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });

    }

    //comprobar los permisos de cámara
    private void checkCameraPermission() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            Log.i("Aviso", "No se tiene permiso para la camara");
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.CAMERA
            }, 225);
        } else {
            Log.i("Mensaje", "Se tiene permiso para usar la camara");
        }
    }



    //usar la camara y cambiar la foto
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CAMERA_ACTION_CODE && resultCode==RESULT_OK && data != null){
            Bundle bundle=data.getExtras();
            finalPhoto=(Bitmap) bundle.get("data");
            foto.setImageBitmap(finalPhoto);
            nuevaFoto();
        }
    }

    //ajusta los botones cuando se introduce la primera foto
    private void nuevaFoto(){
        fecha.setVisibility(View.VISIBLE);
        calendario.setVisibility(View.VISIBLE);
        galeria.setVisibility(View.VISIBLE);
        titulo.setVisibility(View.VISIBLE);

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String date=dateFormat.format(new Date());

        titulo.setText(date);
        fecha.setText(date);
    }


    //guarda una imagen en bitmap en la galeria del telefono
    private void saveImageInGallery(Bitmap yourBitmap, String yourTitle, String yourDescription){
        if(yourTitle.equals(""))yourTitle=yourDescription;
        MediaStore.Images.Media.insertImage(getContentResolver(), yourBitmap, yourTitle , yourDescription);
    }

    //muestra un calendario
    public void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    //cambia la fecha del titulo y fecha cuando se selecciona una en el calendario
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = dayOfMonth + "/" + month + "/" + year;
        fecha.setText(date);
        titulo.setText(date);
    }
}