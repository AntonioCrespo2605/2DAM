package com.example.bbddpokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PokemonInfo extends AppCompatActivity {

    ImageView imagen, tipo1, tipo2, tipoUnico, volver;
    TextView descripcion, nombre, dex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon_info);

        nombre=findViewById(R.id.nombreInfo);
        descripcion=findViewById(R.id.descripcionInfo);
        dex=findViewById(R.id.numDexInfo);
        imagen=findViewById(R.id.imagenInfo);
        tipo1=findViewById(R.id.tipo1img);
        tipo2=findViewById(R.id.tipo2img);
        tipoUnico=findViewById(R.id.solotipo);
        volver=findViewById(R.id.volverInfo);

        Bundle b=getIntent().getExtras();
        int id=b.getInt("id",-1);
        int numDex=b.getInt("numDex",1);
        String nom=b.getString("nombre","Bulbasaur");
        String t1=b.getString("tipo1","acero");
        String t2=b.getString("tipo2", "notype");
        int img=b.getInt("img", R.drawable.bulbasaur);
        String des=b.getString("descripcion","descripcion");

        //ajustar nombre
        nombre.setText(nom);

        //ajustar numero de la dex
        dex.setText("#"+numDex);

        //ajustar tipos
        String tipos[]={"acero","agua","bicho","dragon","electrico","fantasma","fuego","hada","hielo","planta","lucha","normal","psiquico","roca","siniestro","tierra","veneno","volador"};
        int imgs[]={R.drawable.acero,R.drawable.agua,R.drawable.bicho, R.drawable.dragon, R.drawable.electrico, R.drawable.fantasma,
                R.drawable.fuego, R.drawable.hada, R.drawable.hielo, R.drawable.hierba, R.drawable.lucha, R.drawable.normal,
                R.drawable.psiquico, R.drawable.roca, R.drawable.siniestro, R.drawable.tierra, R.drawable.veneno, R.drawable.volador};

        int post1=0;
        int post2=0;
        for(int i=0;i<tipos.length;i++){
            if(t1.equals(tipos[i]))post1=i;
            if(t2.equals(tipos[i]))post2=i;
        }
        tipo1.setImageResource(imgs[post1]);
        tipoUnico.setImageResource(imgs[post1]);
        tipo2.setImageResource(imgs[post2]);

        if(t2.equals("notype")){
            tipo1.setVisibility(View.INVISIBLE);
            tipo2.setVisibility(View.INVISIBLE);
        }else{
            tipoUnico.setVisibility(View.INVISIBLE);
        }

        //ajustar imagen
        imagen.setImageResource(img);

        //ajustar descripcion
        descripcion.setText(des);

        //boton volver
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(PokemonInfo.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

    }
}