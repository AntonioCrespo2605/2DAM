package com.example.bbddpokemon;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Pokemon> pokemons=new ArrayList<Pokemon>();
    private ArrayList <Boolean>selected=new ArrayList<Boolean>();
    private ListView listView;
    private PokemonController pc;
    private boolean editMode=false;
    private Menu m;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //listView
        listView=findViewById(R.id.listView);

        //iniciar el controlador y crear datos por primera vez
        iniciarPokemons();

        //ajustes del adapter
        MyAdapter adapter=new MyAdapter(this, getNombres(pokemons), getImagenes(pokemons), getTipos1(pokemons), getTipos2(pokemons));
        listView.setAdapter(adapter);

        //onclick en cada item pokemon
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if(!editMode){
                    Intent intent=new Intent(MainActivity.this, PokemonInfo.class);
                    intent.putExtra("id",pokemons.get(position).getId());
                    intent.putExtra("nombre",pokemons.get(position).getNombre());
                    intent.putExtra("numDex",pokemons.get(position).getNumDex());
                    intent.putExtra("tipo1",pokemons.get(position).getTipo1());
                    if(pokemons.get(position).getTipo2()!=null)intent.putExtra("tipo2",pokemons.get(position).getTipo2());
                    intent.putExtra("img", pokemons.get(position).getImg());
                    intent.putExtra("descripcion", pokemons.get(position).getDescripcion());
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }else {
                    LinearLayout ll=view.findViewById(R.id.layout);
                    if(selected.get(position)){
                        selected.set(position, false);
                        ll.setBackgroundResource(R.drawable.rounded_edge);
                    }else{
                        selected.set(position, true);
                        ll.setBackgroundResource(R.drawable.rounded_edge_edit);
                    }
                    checkEdit();
                }
            }
        });

        //con el long entramos en el modo edicion
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                if(!editMode) Toast.makeText(MainActivity.this, "Modo edición activado", Toast.LENGTH_SHORT).show();
                editMode=true;
                selected.set(position, true);
                LinearLayout ll=view.findViewById(R.id.layout);
                ll.setBackgroundResource(R.drawable.rounded_edge_edit);
                checkEdit();
                return false;
            }
        });

    }

    //ajusta la visibilidad de los iconos del menu dependiendo de si se entra en modo edición y la cantidad de seleccionados
    private void checkEdit(){
        if(editMode){
            m.findItem(R.id.cancelar).setVisible(true);
            int cont=0;
            for(int i=0;i<selected.size();i++){
                if(selected.get(i))cont++;
            }

            if(cont==0){
                m.findItem(R.id.editar).setVisible(false);
                m.findItem(R.id.borrar).setVisible(false);
            }
            else if(cont==1){
                m.findItem(R.id.editar).setVisible(true);
                m.findItem(R.id.borrar).setVisible(true);
            }else{
                m.findItem(R.id.editar).setVisible(false);
                m.findItem(R.id.borrar).setVisible(true);
            }
        }else{
            m.findItem(R.id.cancelar).setVisible(false);
            m.findItem(R.id.editar).setVisible(false);
            m.findItem(R.id.borrar).setVisible(false);
        }
    }

    //inicia el controlador y añade
    private void iniciarPokemons() {
        pc=new PokemonController(this);
        pokemons=pc.getPokemons();

        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sh.edit();

        boolean iniciada=sh.getBoolean("iniciada",false);

        if(!iniciada){
            Toast.makeText(this, "Iniciada base de datos por defecto", Toast.LENGTH_SHORT).show();
            editor.putBoolean("iniciada",true);
            editor.commit();
            pc.addPokemon(new Pokemon(1, 1, "Bulbasaur", "planta", "veneno", "Este Pokémon nace con una semilla en el lomo, que brota con el paso del tiempo.", R.drawable.bulbasaur));
            pc.addPokemon(new Pokemon(2, 2, "Ivysaur", "planta", "veneno", "Cuando le crece bastante el bulbo del lomo, pierde la capacidad de erguirse sobre las patas traseras.", R.drawable.ivysaur));
            pc.addPokemon(new Pokemon(3, 3, "Venusaur", "planta", "veneno", "La planta florece cuando absorbe energía solar, lo cual le obliga a buscar siempre la luz del sol.", R.drawable.venusaur));
            pc.addPokemon(new Pokemon(4, 4, "Charmander", "fuego", null, "Prefiere las cosas calientes. Dicen que cuando llueve le sale vapor de la punta de la cola.", R.drawable.charmander));
            pc.addPokemon(new Pokemon(5, 5, "Charmeleon", "fuego", null, "Este Pokémon de naturaleza agresiva ataca en combate con su cola llameante y hace trizas al rival con sus afiladas garras.", R.drawable.charmeleon));
            pc.addPokemon(new Pokemon(6, 6, "Charizard", "fuego", "volador", "Escupe un fuego tan caliente que funde las rocas. Causa incendios forestales sin querer.", R.drawable.charizard));
            pc.addPokemon(new Pokemon(7, 7, "Squirtle", "agua", null, "Cuando retrae su largo cuello en el caparazón, dispara agua a una presión increíble.", R.drawable.squirtle));
            pc.addPokemon(new Pokemon(8, 8, "Wartortle", "agua", null, "Se lo considera un símbolo de longevidad. Los ejemplares más ancianos tienen musgo sobre el caparazón.", R.drawable.wartortle));
            pc.addPokemon(new Pokemon(9, 9, "Blastoise", "agua", null, "Para acabar con su enemigo, lo aplasta con el peso de su cuerpo. En momentos de apuro, se esconde en el caparazón.", R.drawable.blastoise));
            pokemons=pc.getPokemons();
        }

        for(int i=0;i<pokemons.size();i++){
            selected.add(false);
        }
    }

    //obtener strings e ints del array
    private String[] getTipos2(ArrayList<Pokemon> pokemons) {
        String[]toret=new String[pokemons.size()];
        for(int i=0;i<pokemons.size();i++){
            toret[i]=pokemons.get(i).getTipo2();
        }
        return toret;
    }

    private String[] getTipos1(ArrayList<Pokemon> pokemons) {
        String[]toret=new String[pokemons.size()];
        for(int i=0;i<pokemons.size();i++){
            toret[i]=pokemons.get(i).getTipo1();
        }
        return toret;
    }

    private int[] getImagenes(ArrayList<Pokemon> pokemons) {
        int[]toret=new int[pokemons.size()];
        for(int i=0;i<pokemons.size();i++){
            toret[i]=pokemons.get(i).getImg();
        }
        return toret;
    }

    private String[] getNombres(ArrayList<Pokemon> pokemons) {
        String[]toret=new String[pokemons.size()];
        for(int i=0;i<pokemons.size();i++){
            toret[i]=pokemons.get(i).getNombre();
        }
        return toret;
    }

    //menu inflater
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        m=menu;
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    //opciones del menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.cancelar:cancelar();
                Toast.makeText(this, "Modo edición cancelado", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.borrar:
                borrar();
                return true;
            case R.id.editar:
                Toast.makeText(this, "editar", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    //al cancelar el modo edicion
    private void cancelar(){
        for(int i=0;i<selected.size();i++){
            selected.set(i, false);
        }
        editMode=false;
        MyAdapter adapter=new MyAdapter(this, getNombres(pokemons), getImagenes(pokemons), getTipos1(pokemons), getTipos2(pokemons));
        listView.setAdapter(adapter);
        checkEdit();
    }

    //boton del menu para borrar
    private void borrar(){
        int cont=0;
        for(int i=0;i<selected.size();i++){
            if(selected.get(i))cont++;
        }
        String sing="Pokemons";
        if(cont==0)sing="Pokemon";

        AlertDialog.Builder altdial = new AlertDialog.Builder(MainActivity.this);
        altdial.setMessage("Estás a punto de eliminar "+cont+" "+sing+"\n¿Estás seguro?").setCancelable(false)
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for(int i=0;i<selected.size();i++){
                            if(selected.get(i)){
                                selected.remove(i);
                                pc.deletePokemon(pokemons.get(i).getId());
                                pokemons=pc.getPokemons();
                                i=0;
                            }
                        }
                        MyAdapter adapter=new MyAdapter(MainActivity.this, getNombres(pokemons), getImagenes(pokemons), getTipos1(pokemons), getTipos2(pokemons));
                        listView.setAdapter(adapter);
                        cancelar();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        cancelar();
                        editMode=true;
                        checkEdit();
                    }
                });

        AlertDialog alert = altdial.create();
        alert.setTitle("Atención");
        alert.show();
    }

    //Adaptador
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String nombres[];
        int imagenes[];
        String tipos1[];
        String tipos2[];

        MyAdapter(Context c, String nombres[],int imagenes[], String tipos1[], String tipos2[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.imagenes=imagenes;
            this.tipos1=tipos1;
            this.tipos2=tipos2;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);

            ImageView img=row.findViewById(R.id.image);
            ImageView tipo1=row.findViewById(R.id.tipo1);
            ImageView tipo2=row.findViewById(R.id.tipo2);
            TextView nombre=row.findViewById(R.id.nombre);

            String tipos[]={"acero","agua","bicho","dragon","electrico","fantasma","fuego","hada","hielo","planta","lucha","normal","psiquico","roca","siniestro","tierra","veneno","volador"};
            int imgs[]={R.drawable.acero,R.drawable.agua,R.drawable.bicho, R.drawable.dragon, R.drawable.electrico, R.drawable.fantasma,
                    R.drawable.fuego, R.drawable.hada, R.drawable.hielo, R.drawable.hierba, R.drawable.lucha, R.drawable.normal,
                    R.drawable.psiquico, R.drawable.roca, R.drawable.siniestro, R.drawable.tierra, R.drawable.veneno, R.drawable.volador};

            img.setImageResource(imagenes[position]);
            nombre.setText(nombres[position]);
            int pos1=0;
            for(int i=0;i<tipos.length;i++){
                if(tipos1[position].equals(tipos[i])){
                    pos1=i;
                    break;
                }
            }
            tipo1.setImageResource(imgs[pos1]);

            if(tipos2[position]==null){
                tipo2.setVisibility(View.INVISIBLE);
            }else{
                tipo2.setVisibility(View.VISIBLE);
                int pos2=0;
                for(int i=0;i<tipos.length;i++){
                    if(tipos2[position].equals(tipos[i])){
                        pos2=i;
                        break;
                    }
                }
                tipo2.setImageResource(imgs[pos2]);
            }


            LinearLayout ll=row.findViewById(R.id.layout);
            if(selected.get(position))ll.setBackgroundResource(R.drawable.rounded_edge_edit);
            else  ll.setBackgroundResource(R.drawable.rounded_edge);
            return row;
        }

        @Override
        public int getViewTypeCount(){
            return getCount();
        }

        @Override
        public int getItemViewType(int position){
            return position;
        }
    }


}