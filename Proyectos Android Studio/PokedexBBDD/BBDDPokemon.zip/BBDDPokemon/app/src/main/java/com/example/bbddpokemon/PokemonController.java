package com.example.bbddpokemon;

import android.content.Context;
import java.util.ArrayList;

//gestiona un arry y el controlador de la bd
public class PokemonController {
    private ArrayList<Pokemon>pokemons;
    private DBHandler handler;

    //constructor
    public PokemonController(Context context){
        this.pokemons=new ArrayList<Pokemon>();
        handler=new DBHandler(context);
        readPokemonsBD();
    }

    //añade al array los pokemons de la bd
    private void readPokemonsBD(){
        this.pokemons=handler.readPokemons();
    }

    //devuelve el array actual
    public ArrayList<Pokemon> getPokemons() {
        return pokemons;
    }

    //modifica el array(no se usa)
    public void setPokemons(ArrayList<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

    //añade un pokemon al array y a la bd
    public void addPokemon(Pokemon p){
        int id=1;
        while(existeId(p.getId())) {
            p.setId(id);
            id++;
        }
        pokemons.add(p);
        handler.addNewPokemon(p);
    }

    //devuelve true si el id esta repetido
    private boolean existeId(int id){
        for(Pokemon p:pokemons) {
            if(p.getId()==id)return true;
        }
        return false;
    }

    //borra un pokemon por su id
    public void deletePokemon(int id){
        for(int i=0;i<pokemons.size();i++){
            if(pokemons.get(i).getId()==id){
                pokemons.remove(i);
                handler.deletePokemon(id);
                break;
            }
        }
    }

    //modifica un pokemon por su id y los datos de otro pokemon nuevo
    public void updatePokemon(int id, Pokemon p){
        p.setId(id);
        for(int i=0;i<pokemons.size();i++){
            if(pokemons.get(i).getId()==id){
                pokemons.set(i, p);
                handler.updatePokemon(id, p);
                break;
            }
        }
    }

    //devuelve el pokemon correspondiente a su id
    public Pokemon getPokemon(int id){
        for(Pokemon p:pokemons){
            if(p.getId()==id)return p;
        }
        return null;
    }
}
