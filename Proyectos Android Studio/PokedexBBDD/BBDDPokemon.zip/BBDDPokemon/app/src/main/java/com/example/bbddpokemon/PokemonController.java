package com.example.bbddpokemon;

import android.content.Context;
import java.util.ArrayList;

public class PokemonController {
    private ArrayList<Pokemon>pokemons;
    private DBHandler handler;

    public PokemonController(Context context){
        this.pokemons=new ArrayList<Pokemon>();
        handler=new DBHandler(context);
        readPokemonsBD();
    }

    private void readPokemonsBD(){
        this.pokemons=handler.readPokemons();
    }

    public ArrayList<Pokemon> getPokemons() {
        return pokemons;
    }

    public void setPokemons(ArrayList<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

    public void addPokemon(Pokemon p){
        int id=1;
        while(existeId(p.getId())) {
            p.setId(id);
            id++;
        }
        pokemons.add(p);
        handler.addNewPokemon(p);
    }

    private boolean existeId(int id){
        for(Pokemon p:pokemons) {
            if(p.getId()==id)return true;
        }
        return false;
    }

    public void deletePokemon(int id){
        for(int i=0;i<pokemons.size();i++){
            if(pokemons.get(i).getId()==id){
                pokemons.remove(i);
                handler.deletePokemon(id);
                break;
            }
        }
    }

    public void updatePokemon(int id, Pokemon p){
        for(int i=0;i<pokemons.size();i++){
            if(pokemons.get(i).getId()==id){
                pokemons.set(i, p);
                handler.updatePokemon(id, p);
                break;
            }
        }
    }
}
