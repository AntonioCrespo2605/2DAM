package com.example.bbddpokemon;

public class Pokemon {
    private int id, numDex, img;
    private String nombre, tipo1, tipo2, descripcion;

    public Pokemon(int id, int numDex, String nombre, String tipo1, String tipo2, String descripcion, int img){
        this.id=id;
        this.numDex=numDex;
        this.img=img;
        this.nombre=nombre;
        this.tipo1=tipo1;
        this.tipo2=tipo2;
        this.descripcion=descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumDex() {
        return numDex;
    }

    public void setNumDex(int numDex) {
        this.numDex = numDex;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo1() {
        return tipo1;
    }

    public void setTipo1(String tipo1) {
        this.tipo1 = tipo1;
    }

    public String getTipo2() {
        return tipo2;
    }

    public void setTipo2(String tipo2) {
        this.tipo2 = tipo2;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
