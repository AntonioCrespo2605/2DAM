package com.example.bbddpokemon;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME="pokemonsDB";
    private static final String POKEMON_TABLE="pokemon";
    private static final int DB_VERSION=1;
    //atributos
    private static final String ID_COL="id";
    private static final String NUM_DEX_COL="num_dex";
    private static final String NOMBRE_COL="nombre";
    private static final String TIPO_1_COL="tipo1";
    private static final String TIPO_2_COL="tipo2";
    private static final String DESCRIPCION_DEX_COL="descripcion_dex";
    private static final String IMAGEN_COL="imagen";

    public DBHandler(Context context){
        super(context, DB_NAME,null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query ="CREATE TABLE "+POKEMON_TABLE+" ("
                +ID_COL+" INTEGER PRIMARY KEY AUTOINCREMENT, "
                +NUM_DEX_COL+" INTEGER NOT NULL, "
                +NOMBRE_COL+" TEXT NOT NULL,"
                +TIPO_1_COL+" TEXT NOT NULL,"
                +TIPO_2_COL+" TEXT,"
                +DESCRIPCION_DEX_COL+" TEXT NOT NULL,"
                +IMAGEN_COL+" INTEGER NOT NULL)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+POKEMON_TABLE);
        onCreate(db);
    }

    public ArrayList<Pokemon> readPokemons(){
        ArrayList<Pokemon>toret=new ArrayList<Pokemon>();

        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+POKEMON_TABLE, null);

        if(cursor.moveToFirst()){
            do{
                //(id, numDex, nombre, tipo1, tipo2, descripcion, imagen)
                toret.add(new Pokemon(cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getInt(6)));
            }while(cursor.moveToNext());
        }
        return toret;
    }

    public void addNewPokemon(Pokemon pokemon){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(ID_COL, pokemon.getId());
        values.put(NUM_DEX_COL, pokemon.getNumDex());
        values.put(NOMBRE_COL, pokemon.getNombre());
        values.put(TIPO_1_COL, pokemon.getTipo1());
        values.put(TIPO_2_COL, pokemon.getTipo2());
        values.put(DESCRIPCION_DEX_COL, pokemon.getDescripcion());
        values.put(IMAGEN_COL,pokemon.getImg());

        db.insert(POKEMON_TABLE, null, values);
        db.close();
    }

    public void deletePokemon(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(POKEMON_TABLE, ID_COL+"="+id, null);
        db.close();
    }

    public void updatePokemon(int id_viejo, Pokemon pokemon){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID_COL, pokemon.getId());
        values.put(NUM_DEX_COL, pokemon.getNumDex());
        values.put(NOMBRE_COL, pokemon.getNombre());
        values.put(TIPO_1_COL, pokemon.getTipo1());
        values.put(TIPO_2_COL, pokemon.getTipo2());
        values.put(DESCRIPCION_DEX_COL, pokemon.getDescripcion());
        values.put(IMAGEN_COL, pokemon.getImg());

        db.update(POKEMON_TABLE, values, ID_COL+"="+id_viejo, null);
        db.close();
    }
}
