package com.example.bbddpokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class EditarCrearPokemon extends AppCompatActivity {

    private Button crearModificar;
    private ImageView t1, t2, img;
    private EditText numDex, nombre, descripcion;
    private int posImg=0;

    private ImageView volver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_crear_pokemon);

        crearModificar=findViewById(R.id.crear);
        volver=findViewById(R.id.volverEdit);
        t1=findViewById(R.id.editt1);
        t2=findViewById(R.id.editt2);
        img=findViewById(R.id.editimg);
        numDex=findViewById(R.id.editNum);
        nombre=findViewById(R.id.editNom);
        descripcion=findViewById(R.id.editDes);

        //ocultar actionbar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        Bundle b=getIntent().getExtras();
        boolean editar=b.getBoolean("editar", false);

        int[]imagenes={R.drawable.beedrill, R.drawable.blastoise, R.drawable.bulbasaur, R.drawable.butterfree, R.drawable.caterpie, R.drawable.charizard
        ,R.drawable.charmander, R.drawable.charmeleon, R.drawable.ivysaur, R.drawable.kakuna, R.drawable.metapod, R.drawable.squirtle, R.drawable.venusaur
        ,R.drawable.wartortle, R.drawable.weedle};

        if (editar){
            crearModificar.setText("Modificar");
        }else{

        }

        //volver sin guardar
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(EditarCrearPokemon.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        //cambiar la imagen correspondiente
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posImg++;
                if(posImg>=imagenes.length)posImg=0;
                img.setImageResource(imagenes[posImg]);
            }
        });

        //boton de modificar o crear
        crearModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editar){
                    if(checkCampos()){

                    }
                }
            }
        });

    }

    //comprueba los campos rellenados
    private boolean checkCampos() {
        String 
    }
}