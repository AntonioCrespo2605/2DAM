package com.example.bbddpokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class EditarCrearPokemon extends AppCompatActivity {

    //boton, editables, imagenes
    private Button crearModificar;
    private ImageView t1, t2, img;
    private EditText numDex, nombre, descripcion;
    private ImageView volver;

    //controlador
    private PokemonController pc;

    //variables auxiliares
    private int posTipo1=0, posTipo2=1, posImg=0, id=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_crear_pokemon);

        crearModificar=findViewById(R.id.crear);
        volver=findViewById(R.id.volverEdit);
        t1=findViewById(R.id.editt1);
        t2=findViewById(R.id.editt2);
        img=findViewById(R.id.editimg);
        numDex=findViewById(R.id.editNum);
        nombre=findViewById(R.id.editNom);
        descripcion=findViewById(R.id.editDes);

        //ocultar actionbar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        //iniciar gestor de BBDD
        pc=new PokemonController(this);

        //recoger si se trata del modo edicion
        Bundle b=getIntent().getExtras();
        boolean editar=b.getBoolean("editar", false);
        id=b.getInt("id", 1);

        //imagenes de pokemon
        int[]imagenes={R.drawable.beedrill, R.drawable.blastoise, R.drawable.bulbasaur, R.drawable.butterfree, R.drawable.caterpie, R.drawable.charizard
        ,R.drawable.charmander, R.drawable.charmeleon, R.drawable.ivysaur, R.drawable.kakuna, R.drawable.metapod, R.drawable.squirtle, R.drawable.venusaur
        ,R.drawable.wartortle, R.drawable.weedle};

        //nombres de tipos e imagenes
        String tipos[]={"null","acero","agua","bicho","dragon","electrico","fantasma","fuego","hada","hielo","planta","lucha","normal","psiquico","roca","siniestro","tierra","veneno","volador"};
        int imgs[]={R.drawable.menos,R.drawable.acero,R.drawable.agua,R.drawable.bicho, R.drawable.dragon, R.drawable.electrico, R.drawable.fantasma,
                R.drawable.fuego, R.drawable.hada, R.drawable.hielo, R.drawable.hierba, R.drawable.lucha, R.drawable.normal,
                R.drawable.psiquico, R.drawable.roca, R.drawable.siniestro, R.drawable.tierra, R.drawable.veneno, R.drawable.volador};

        //volver sin guardar
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(EditarCrearPokemon.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        //cambiar la imagen correspondiente
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posImg++;
                if(posImg>=imagenes.length)posImg=0;
                img.setImageResource(imagenes[posImg]);
            }
        });


        t1.setImageResource(R.drawable.acero);
        //cambiar el tipo 1
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posTipo1++;
                if(posTipo1>= tipos.length)posTipo1=1;
                if(posTipo1==posTipo2)posTipo1++;
                if(posTipo1>= tipos.length)posTipo1=1;
                t1.setImageResource(imgs[posTipo1]);
            }
        });

        t2.setImageResource(R.drawable.menos);
        //cambiar el tipo 2
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posTipo2++;
                if(posTipo2>=tipos.length)posTipo2=0;
                if(posTipo2==posTipo1)posTipo2++;
                if(posTipo2>=tipos.length)posTipo2=0;
                t2.setImageResource(imgs[posTipo2]);
            }
        });

        //boton de modificar o crear
        crearModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editar){
                    if(checkCampos()){
                        String tipo2=tipos[posTipo2];
                        if(posTipo2 == 0)tipo2=null;
                        pc.updatePokemon(id,new Pokemon(1, Integer.parseInt(numDex.getText().toString()), nombre.getText().toString(), tipos[posTipo1], tipo2, descripcion.getText().toString(), imagenes[posImg]) );
                        Intent intent=new Intent(EditarCrearPokemon.this,MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                }else{
                    if(checkCampos()){
                        String tipo2=tipos[posTipo2];
                        if(posTipo2 == 0)tipo2=null;
                        pc.addPokemon(new Pokemon(1, Integer.parseInt(numDex.getText().toString()), nombre.getText().toString(), tipos[posTipo1], tipo2, descripcion.getText().toString(), imagenes[posImg]));
                        Intent intent=new Intent(EditarCrearPokemon.this,MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                }
            }
        });

        //si es para editar se rellenan los campos
        if (editar){
            crearModificar.setText("Modificar");
            Pokemon modelo=pc.getPokemon(id);
            numDex.setText(modelo.getNumDex()+"");
            descripcion.setText(modelo.getDescripcion());
            nombre.setText(modelo.getNombre());
            int p=0;
            for(int i=0;i<imagenes.length;i++){
                if(imagenes[i]==modelo.getImg()){
                    p=i;
                    img.setImageResource(modelo.getImg());
                    break;
                }
            }
            posImg=p;

            int p1=0;
            for(int i=0;i<tipos.length;i++){
                if(tipos[i].equals(modelo.getTipo1())){
                    p1=i;
                    t1.setImageResource(imgs[i]);
                    break;
                }
            }
            posTipo1=p1;

            int p2=0;
            if(modelo.getTipo2()==null){
                p2=0;
                t2.setImageResource(R.drawable.menos);
            }else{
                for(int i=1;i<tipos.length;i++){
                    if(tipos[i].equals(modelo.getTipo2())){
                        p2=i;
                        t2.setImageResource(imgs[i]);
                        break;
                    }
                }
            }
            posTipo2=p2;
        }

    }

    //comprueba los campos rellenados
    private boolean checkCampos() {
        String num=numDex.getText().toString();
        String nom=nombre.getText().toString();
        String des=descripcion.getText().toString();
        num=num.trim();
        nom=nom.trim();
        des=des.trim();
        try{
            int n=Integer.parseInt(num);
            if(n<=0) {
                Toast.makeText(this, "El número de pokedex ha de ser 1 o mayor", Toast.LENGTH_SHORT).show();
                return false;
            }
        }catch (Exception e){
            Toast.makeText(this, "Error en el formato del número de pokedex.(1->x)", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(nom==null||nom==""){
            Toast.makeText(this, "El pokémon ha de tener nombre", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(des==null||des==""){
            Toast.makeText(this, "El pokémon ha de tener descripción", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}