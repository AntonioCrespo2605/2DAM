package com.example.swimmingwithnessie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class CrearEntrenamiento extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    EditText etPlannedDate, distancia, minutos, segundos;
    ImageView registrar, cancelar;
    String currentDateString="";

    TextView pr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_entrenamiento);

        Intent intent = getIntent();
        if(intent.hasExtra(Intent.EXTRA_TEXT)){
            Bundle extras = getIntent().getExtras();
        }

        pr=findViewById(R.id.prueba);
        registrar=findViewById(R.id.registrarT);
        etPlannedDate=findViewById(R.id.fechaEditText);
        cancelar=findViewById(R.id.cancelar);
        distancia=findViewById(R.id.fechaEditText);
        minutos=findViewById(R.id.minEditText);
        segundos=findViewById(R.id.segEditText);
        distancia=findViewById(R.id.distanciaTextEdit);

        etPlannedDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nFecha=currentDateString;
                String nDis=distancia.getText().toString();
                String nMin=minutos.getText().toString();
                String nSeg=segundos.getText().toString();

                pr.setText("("+nFecha+")("+nDis+")("+nMin+")"+"("+nSeg+")");

                if(nFecha.matches("")||nDis.matches("")||nMin.matches("")||nSeg.matches("")){
                    Context context = getApplicationContext();
                    CharSequence text = "Algo tienes mal";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }else{
                    SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = sh.edit();
                    int num=sh.getInt("num",0);
                    num+=1;
                    myEdit.putInt("num", num);
                    myEdit.putString(num+"fecha", nFecha);
                    myEdit.putInt(num+"min", Integer.parseInt(nMin));
                    myEdit.putInt(num+"seg", Integer.parseInt(nSeg));
                    myEdit.putString(num+"dist", nDis);
                    myEdit.commit();

                    Intent intent = new Intent(CrearEntrenamiento.this, Vista.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
            }
        });

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CrearEntrenamiento.this, Vista.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        Calendar c=Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DATE, day);
        currentDateString= DateFormat.getDateInstance(DateFormat.FULL).format(c.getTime());
        etPlannedDate.setHint(currentDateString);
    }
}