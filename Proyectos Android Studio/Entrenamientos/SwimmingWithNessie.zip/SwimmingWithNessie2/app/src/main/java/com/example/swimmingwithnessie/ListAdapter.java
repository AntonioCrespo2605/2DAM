package com.example.swimmingwithnessie;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> implements View.OnClickListener{
    private List<ListElement> mData;
    private LayoutInflater mInflater;
    private Context context;
    private View.OnClickListener listener;
    private ArrayList<Integer>numDisponibles;



    public ListAdapter(List<ListElement> itemList, Context context, ArrayList<Integer>numDisponibles){
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.mData = itemList;
        this.numDisponibles=numDisponibles;
    }

    @Override
    public int getItemCount(){return mData.size();}

    @Override
    public ListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = mInflater.inflate(R.layout.list_element, null);
        view.setOnClickListener(this);
        return new ListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ListAdapter.ViewHolder holder, final int position){
        holder.binData(mData.get(position));

        final ListElement listElement=this.mData.get(position);

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                PopupMenu popupMenu=new PopupMenu(context, view, Gravity.RIGHT);
                MenuInflater inflater=popupMenu.getMenuInflater();
                inflater.inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.action_popup_edit:
                                Intent inte = new Intent(context, CrearEntrenamiento.class);
                                inte.putExtra(Intent.EXTRA_TEXT, menuItem.getItemId());
                                borrarItem(listElement);

                                context.startActivity(inte);
                                break;
                            case R.id.action_popup_delete:
                                borrarItem(listElement);
                                break;

                        }
                        return false;
                    }
                });
                popupMenu.show();
                return true;
            }
        });
    }

    public void borrarItem(ListElement position){
        int pos= mData.indexOf(position);
        Toast.makeText(context, "Entrenamiento eliminado", Toast.LENGTH_SHORT).show();
        mData.remove(position);

        String clavefecha=numDisponibles.get(pos)+"fecha";
        String clavemin=numDisponibles.get(pos)+"min";
        String claveseg=numDisponibles.get(pos)+"seg";
        String clavedistancia=numDisponibles.get(pos)+"dist";
        SharedPreferences sh= context.getSharedPreferences("MySharedPref", context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sh.edit();

        editor.remove(clavemin);
        editor.remove(claveseg);
        editor.remove(clavedistancia);
        editor.remove(clavefecha);
        editor.commit();

        this.numDisponibles.remove(pos);
    }

    public void setItems(List<ListElement> items){mData = items;}

    @Override
    public void onClick(View view) {
        if(listener!=null){
            listener.onClick(view);
        }
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener=listener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private static final String TAG = "MyViewHolder";

        TextView fecha, datos1, datos2;
        LinearLayout ll;
        ViewHolder(View itemView){
            super(itemView);
            fecha=itemView.findViewById(R.id.fechaTextView);
            datos1=itemView.findViewById(R.id.datos1TextView);
            datos2=itemView.findViewById(R.id.datos2TextView);
            ll=itemView.findViewById(R.id.clicHere);
        }

        void binData(final ListElement item) {
            fecha.setText(item.getFecha());
            datos1.setText(item.getDistanciaMetros()+" metros");
            datos2.setText(item.getMinutos()+":"+item.getSegundos());

        }

    }



}
