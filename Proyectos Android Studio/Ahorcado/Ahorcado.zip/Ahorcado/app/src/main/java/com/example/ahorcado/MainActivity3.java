package com.example.ahorcado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        String aux=intent.getStringExtra("t");
        TextView tv=findViewById(R.id.victoria);
        ImageView iv=findViewById(R.id.finalimg);
        switch(aux){
            case"true":
                iv.setImageDrawable(getDrawable(R.drawable.victoria));
                tv.setText("Victoria");
                tv.setTextColor(Color.parseColor("#70C352"));
                break;
            case"false":
                iv.setImageDrawable(getDrawable(R.drawable.derrota));
                tv.setText("Derrota");
                tv.setTextColor(Color.parseColor("#BD1F1F"));
                break;
            default:
                break;
        }
        Button e=findViewById(R.id.exit);
        Button c=findViewById(R.id.replay);

        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }
}