/*@author: Antonio Crespo*/
package com.example.ahorcado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class MainActivity2 extends AppCompatActivity {
    String oculto;
    int tries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String[] palabras = {"cachivache","ahorcado","dinosaurio",
                "farolillo","aromatizante","aburrimiento","alcantarilla","cuchillo","desierto",
                "caniche","pancracio","sudadera","manofactura","pomo","rabano","azulado","teclado",
                "papel","lactoso","improvisar","virus","hotel","zapato","control","automatizacion",
                "flor","balonmano","futbol","litera","original","navaja","esternocleidomastoideo",
                "explicar","anillo","comunidad","entrelazar","implementar","desventajas","piramide",
                "sol","higado", "corazon", "pantalon", "accion", "guion", "palo", "jubilacion" ,"forro",
                "millonario", "chofer", "coco","macaco","palmera", "gato", "rueda", "gominola","aplicacion",
                "ardilla", "lucha", "libertad", "guerra", "utilidad", "olimpiadas", "viernes", "humanidad",
                "lanza", "baston", "bastardo", "huevo", "dragon", "actividad", "aparentar", "auriculares", "casco",
                "madera", "acero", "luz", "mar", "sombra", "animal", "loco", "dinosaurio","pantalla", "cordon",
                "acordeon", "guitarra", "flauta", "pesca", "altura", "ibuporfeno", "lucidez", "locutor", "tension",
                "musculo", "mascarilla", "calzoncillo", "bolsillo", "interruptor", "herida", "beta", "fotografia"};
        ArrayList<Character>usados=new ArrayList<Character>();
        String palabra;

        tries=6;

        Random r=new Random();
        palabra=palabras[r.nextInt(palabras.length)];
        oculto="";
        for(int i=0;i< palabra.length();i++){
            oculto+="-";
        }

        ImageView ah=findViewById(R.id.ahorcado);
        ah.setImageDrawable(getDrawable(R.drawable.nada2));
        TextView usadas=findViewById(R.id.usadas);
        TextView intentos= findViewById(R.id.intentos);
        TextView palabraOculta= findViewById(R.id.palabra);
        palabraOculta.setText(oculto);

        Button b= findViewById(R.id.probar);
        TextInputEditText tied= findViewById(R.id.letra);
        b.setOnClickListener(view -> {
            String aux;
            aux = Objects.requireNonNull(tied.getText()).toString();
            aux+=".";
            aux=aux.toLowerCase();
            boolean encontrado;
            char c=aux.charAt(0);
            if((int)c==225)c='a';
            else if ((int)c==233)c='e';
            else if ((int)c==237)c='i';
            else if ((int)c==243)c='o';
            else if ((int)c==250)c='u';

            //en ascii la a es el 97 y la z el 122. Si no está en ese rango no es una letra permitida. La ñ es la 241
            if(((int)c<97 || (int)c>122)&&(int)c!=241) {
                Toast error = Toast.makeText(getApplicationContext(), "El primer caracter no está entre la a y la z", Toast.LENGTH_SHORT);
                error.show();
            }else {
                //si ya a sido usado no lo comprobamos ni contamos como error
                if(usados.contains(c)){
                    Toast error = Toast.makeText(getApplicationContext(), "Caracter ya usado", Toast.LENGTH_SHORT);
                    error.show();
                }else {
                    String aux4="";
                    usados.add(c);
                    encontrado=false;

                    //comprobar si la palabra contiene la letra y quitar asteriscos si la tiene
                    for(int i=0;i<palabra.length();i++) {
                        char aux3=palabra.charAt(i);
                        if(c==aux3) {
                            encontrado=true;
                            aux4+=c;
                        }else aux4+=oculto.charAt(i);
                    }
                    oculto=aux4;

                    if(!encontrado) {
                        tries--;
                    }
                }
            }
            palabraOculta.setText(oculto);
            intentos.setText(tries+" ");
            String usd="";
            for (int i=0;i<usados.size();i++){
                usd+=usados.get(i)+",";
            }
            usadas.setText(usd);
            if(palabra.equals(oculto)){
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("t","true");
                startActivity(intent);
                finish();
            }
            if(tries==0) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("t","false");
                startActivity(intent);
                finish();
            }

            switch(tries){
                case 0:ah.setImageDrawable(getDrawable(R.drawable.entero2));
                    break;
                case 1:ah.setImageDrawable(getDrawable(R.drawable.unapierna2));
                    break;
                case 2:ah.setImageDrawable(getDrawable(R.drawable.dosbrazo2));
                    break;
                case 3:ah.setImageDrawable(getDrawable(R.drawable.unbrazo2));
                    break;
                case 4:ah.setImageDrawable(getDrawable(R.drawable.cuerpo2));
                    break;
                case 5:ah.setImageDrawable(getDrawable(R.drawable.cabeza2));
                    break;
                default:ah.setImageDrawable(getDrawable(R.drawable.nada2));
                    break;
            }

        });

    }
}