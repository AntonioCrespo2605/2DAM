package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    //contenedor de contactos
    private ArrayList<Contacto>contactos=new ArrayList<Contacto>();
    private DialogInterface.OnClickListener dialogClickListener;
    private ListView listView;
    private boolean editar, borrar;
    private Menu m;

    //imagenes de drawable
    private static final int[]DINOS={R.drawable.anquilo, R.drawable.bronto, R.drawable.estego, R.drawable.parasaurio, R.drawable.ptera, R.drawable.raptor, R.drawable.rex,R.drawable.teri, R.drawable.trike};
    /**
     * 0-anquilosaurio
     * 1-brontosaurio
     * 2-estegosaurio
     * 3-parasaurio
     * 4-pteranodon
     * 5-raptor
     * 6-rex
     * 7-tericinosaurio
     * 8-triceratops
     * **/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //si están a true entrarán en su correspondiente metodo en el onclick
        borrar=false;
        editar=false;

        //contactos de serie
        contactos=iniciarContactos();

        //iniciar listView
        listView=findViewById(R.id.listView2);

        //ajustamos el adapter
        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getDinos(contactos));
        listView.setAdapter(adapter);

        //onclick en cada contacto
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //abrir info
                if(!editar&&!borrar){
                    Intent intent = new Intent(MainActivity.this, InfoContacto.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("clave",contactos.get(position).getId());
                    intent.putExtra("nombre", contactos.get(position).getNombre());
                    intent.putExtra("apellidos", contactos.get(position).getApellidos());
                    intent.putExtra("telefono", contactos.get(position).getTelefono());
                    intent.putExtra("email", contactos.get(position).getEmail());
                    intent.putExtra("direccion", contactos.get(position).getDireccion());
                    intent.putExtra("observaciones", contactos.get(position).getObservaciones());
                    intent.putExtra("apodo", contactos.get(position).getApodo());
                    intent.putExtra("dino", contactos.get(position).getDino());
                    startActivity(intent);
                    finish();
                //modo edita
                }else if(editar){
                    Intent intent = new Intent(MainActivity.this, NuevoModificar.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("editar", true);
                    intent.putExtra("clave",contactos.get(position).getId());
                    intent.putExtra("nombre", contactos.get(position).getNombre());
                    intent.putExtra("apellidos", contactos.get(position).getApellidos());
                    intent.putExtra("telefono", contactos.get(position).getTelefono());
                    intent.putExtra("email", contactos.get(position).getEmail());
                    intent.putExtra("direccion", contactos.get(position).getDireccion());
                    intent.putExtra("observaciones", contactos.get(position).getObservaciones());
                    intent.putExtra("apodo", contactos.get(position).getApodo());
                    intent.putExtra("dino", contactos.get(position).getDino());
                    startActivity(intent);
                    finish();
                //modo borrar
                }else if(borrar){
                    AlertDialog.Builder altdial = new AlertDialog.Builder(MainActivity.this);
                    altdial.setMessage("Estás a punto de eliminar a "+contactos.get(position).getNombre()+" de tus contactos.\n¿Estas seguro?").setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    eliminarPos(position);
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    cancelar();
                                }
                            });

                    AlertDialog alert = altdial.create();
                    alert.setTitle("Atención");
                    alert.show();
                }
            }
        });



    }

    //menu inflater
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        m=menu;
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    //Adaptador
    class MyAdapter extends ArrayAdapter<String>{
        Context context;
        String nombres[];
        String apodos[];
        int dinos[];

        MyAdapter(Context c, String nombres[], String apodos[],int dinos[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.apodos=apodos;
            this.dinos=dinos;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);

            ImageView dino=row.findViewById(R.id.image);
            TextView nombre=row.findViewById(R.id.nombre);
            TextView apodo=row.findViewById(R.id.apodo);

            dino.setImageResource(dinos[position]);
            nombre.setText(nombres[position]);
            apodo.setText(apodos[position]);

            return row;
        }
    }

    //inicia el arrayList de contactos leyendo de las shared preferences
    private ArrayList<Contacto> iniciarContactos(){
        ArrayList<Contacto>contactos=new ArrayList<Contacto>();

        //para leer y escribir en las shared
        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);

        //recogemos todos los contactos guardados
        int totales=sh.getInt("totales",8);

        //Valores por defecto
        String[]nombsDef={"Antonio","Ivan","Aitana","Xandre","Naila","Yessica","Sergio","Javier"};
        String[]apesDef={"Crespo Gómez", "Cernadas Fragueiro", "Rodríguez Vidal", "Martínez Correia", "Álvarez Suárez", "Rodríguez González","Fernández Rodríguez","Loureiro Pérez"};
        String[]emailsDef={"antonio@gmail.com", "ivan@gmail.com", "aitana@gmail.com","xandre@gmail.com","naila@gmail.com","yessica@gmail.com","sergio@gmail.com","javier@gmail.com"};
        String[]direccionesDef={"cesantes","pousiño","gran vía","moscoso","teis","ponteareas","mercadona(sección de frutas)","cerca de aitana"};
        String[]apodosDef={"Rey Dinosaurio","Bachatosaurio","Tericinosaurio","Macacopitecus","Navajasaurio","Fotosaurio","Nanosaurio","¿Qué?tsal"};
        int[]dinosDef={3,1,7,0,5,2,4,8,6};

        String nombre, apellidos, telefono, email,direccion,observaciones,apodo;
        int id, dino;
        for(int i=0;i<totales;i++){
            if(sh.getBoolean("disponible"+i, true)){
                id=i;
                //los 8 primeros son por defecto
                if(i<8){
                    nombre=sh.getString("nombre"+id,nombsDef[i]);
                    apellidos= sh.getString("apellidos"+id,apesDef[i]);
                    telefono=sh.getString("telefono"+id,i+""+i+""+i+""+i+""+i+""+i+""+i+""+i+""+i);
                    email=sh.getString("email"+id,emailsDef[i]);
                    direccion=sh.getString("direccion"+id,direccionesDef[i]);
                    observaciones=sh.getString("observaciones"+id,"guapisim@");
                    apodo=sh.getString("apodo"+id,apodosDef[i]);
                    dino=sh.getInt("dino"+id,DINOS[dinosDef[i]]);
                }else{
                    //estos son los generados por el usuario
                    nombre=sh.getString("nombre"+id,"default");
                    apellidos= sh.getString("apellidos"+id,"default");
                    telefono=sh.getString("telefono"+id,"default");
                    email=sh.getString("email"+id,"default");
                    direccion=sh.getString("direccion"+id,"default");
                    observaciones=sh.getString("observaciones"+id,"default");
                    apodo=sh.getString("apodo"+id,"default");
                    dino=sh.getInt("dino"+id,0);
                }
                contactos.add(new Contacto(id,nombre,apellidos,telefono,email,direccion,observaciones,apodo,dino));
            }
        }
        return contactos;
    }

    //devuelve un array con los nombres de contactos
    private String[]getNombres(ArrayList<Contacto>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getNombre();
        }
        return toret;
    }

    //devuelve un array con las imagenes de cada contacto
    private int []getDinos(ArrayList<Contacto>contactos){
        int toret[]=new int[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getDino();
        }
        return toret;
    }

    //devuelve un array con los apodos de contactos
    private String[]getApodos(ArrayList<Contacto>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getApodo();
        }
        return toret;
    }

    //randomiza el array de contactos
    private void randomArray(){
        Collections.shuffle(contactos);
        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getDinos(contactos));
        listView.setAdapter(adapter);
    }

    //cambia de activity a la de crear contacto
    private void crearContacto(){
        Intent intent = new Intent(MainActivity.this, NuevoModificar.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("editar",false);
        startActivity(intent);
        finish();
    }

    //gestiona el booleano de borrar y juega con la visibilidad del boton de cancelar
    private void borrarContacto(){
        if(!borrar){
            Toast.makeText(this, "Cancelar en icono de cancelar en el menu o toca de nuevo borrar", Toast.LENGTH_SHORT).show();
            borrar=true;
            editar=false;
            listView.setBackgroundColor(getResources().getColor(R.color.rojo_eliminar));
            m.findItem(R.id.cancelar).setVisible(true);
        }else{
            borrar=false;
            editar=false;
            listView.setBackgroundColor(getResources().getColor(R.color.verde_fondo));
            m.findItem(R.id.cancelar).setVisible(false);
        }
    }

    //gestiona el booleano de editar y juega con la visibilidad del boton de cancelar
    private void editarContacto(){
        if(!editar){
            Toast.makeText(this, "Cancelar en icono de cancelar en el menu o toca de nuevo editar", Toast.LENGTH_SHORT).show();
            borrar=false;
            editar=true;
            listView.setBackgroundColor(getResources().getColor(R.color.naranja_editar));
            m.findItem(R.id.cancelar).setVisible(true);
        }else{
            borrar=false;
            editar=false;
            listView.setBackgroundColor(getResources().getColor(R.color.verde_fondo));
            m.findItem(R.id.cancelar).setVisible(false);
        }
    }

    //cancela la eliminacion o la edicion
    private void cancelar(){
        m.findItem(R.id.cancelar).setVisible(false);
        borrar=false;
        editar=false;
        listView.setBackgroundColor(getResources().getColor(R.color.verde_fondo));
    }

    //elimina el contacto de la lista dada su posicion
    private void eliminarPos(int pos){
        int id=contactos.get(pos).getId();

        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sh.edit();
        editor.putBoolean("disponible"+id, false);
        editor.commit();
        contactos.remove(pos);
        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getDinos(contactos));
        listView.setAdapter(adapter);
    }

    //recupera los contactos de serie
    private void recuperar(){
        SharedPreferences sh = getSharedPreferences("MyPrefs", 0);
        SharedPreferences.Editor editor = sh.edit();
        for(int i=0;i<8;i++){
            editor.remove("nombre"+i);
            editor.remove("apellidos"+i);
            editor.remove("telefono"+i);
            editor.remove("email"+i);
            editor.remove("direccion"+i);
            editor.remove("observaciones"+i);
            editor.remove("apodo"+i);
            editor.remove("dino"+i);
            editor.remove("disponible"+i);
            editor.commit();
        }

        contactos=iniciarContactos();
        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getDinos(contactos));
        listView.setAdapter(adapter);
    }

    //opciones del menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.cancelar:
                cancelar();
                return true;
            case R.id.random:
                randomArray();
                return true;
            case R.id.borrar:
                borrarContacto();
                return true;
            case R.id.editar:
                editarContacto();
                return true;
            case R.id.nuevo:
                crearContacto();
                return true;
            case R.id.salir:
                finish();
                return true;
            case R.id.recuperar:
                recuperar();
                return true;
            case R.id.ajustes:
                startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}