package com.example.miscontactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class NuevoModificar extends AppCompatActivity {

    EditText nombre, apellidos, telefono, apodo, email, direccion, observaciones;
    int imagenRes;
    int clave;
    ImageView perfil, volver, confirmar;
    private static final int[]DINOS={R.drawable.anquilo, R.drawable.bronto, R.drawable.estego, R.drawable.parasaurio, R.drawable.ptera, R.drawable.raptor, R.drawable.rex,R.drawable.teri, R.drawable.trike};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_modificar);

        //editTexts
        nombre=findViewById(R.id.editNombre);
        apellidos=findViewById(R.id.editApellidos);
        telefono=findViewById(R.id.editTelefono);
        apodo=findViewById(R.id.editApodo);
        email=findViewById(R.id.editEmail);
        direccion=findViewById(R.id.editDireccion);
        observaciones=findViewById(R.id.editObservaciones);

        //imagen perfil
        perfil=findViewById(R.id.imagenNuevo);

        //boton de volver
        volver=findViewById(R.id.volvernuevo);

        //boton para crear/editar
        confirmar=findViewById(R.id.confirmar);

        //ocultar actionbar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        //bundle para ver si es una pestaña de edición o creado nuevo. Si editar esta a true es para editar. Sino es de creación
        Bundle b=getIntent().getExtras();
        boolean ediarB=b.getBoolean("editar", false);

        //posición en el array de dinos de la imagen mostrada
        imagenRes=0;

        //si se quiere editar se rellenan los campos con la información guardada
        if(ediarB){
            clave=b.getInt("clave", 0);
            nombre.setText(b.getString("nombre",""));
            apellidos.setText(b.getString("apellidos",""));
            telefono.setText(b.getString("telefono",""));
            email.setText(b.getString("email",""));
            direccion.setText(b.getString("direccion",""));
            observaciones.setText(b.getString("observaciones",""));
            apodo.setText(b.getString("apodo",""));
            perfil.setImageResource(b.getInt("dino", DINOS[0]));

            //actualizamos la posición de la imagen mostrada si se manda a editar
            for(int i=0;i<DINOS.length;i++){
                if(DINOS[i]==b.getInt("dino")){
                    imagenRes=i;
                    break;
                }
            }
        }

        //al hacer click en la imagen se cambia
        perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imagenRes++;
                if(imagenRes==DINOS.length)imagenRes=0;
                perfil.setImageResource(DINOS[imagenRes]);
            }
        });

        //al hacer click vuelve al menú de contactos
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NuevoModificar.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        //al hacer click en confirmar comprueba que pueda añadirlo/modificarlo y en caso afirmativo lo hace
        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(verificar()){
                    SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sh.edit();

                    if(!ediarB) {
                        clave = sh.getInt("totales", 8);
                        editor.putInt("totales", clave + 1);
                    }

                    editor.putString("nombre"+clave,nombre.getText().toString().trim());
                    editor.putString("apellidos"+clave, apellidos.getText().toString().trim());
                    editor.putString("telefono"+clave, telefono.getText().toString().trim());
                    editor.putString("email"+clave, email.getText().toString().trim());
                    editor.putString("direccion"+clave, direccion.getText().toString().trim());
                    editor.putString("observaciones"+clave, observaciones.getText().toString().trim());
                    editor.putString("apodo"+clave, apodo.getText().toString().trim());
                    editor.putInt("dino"+clave, DINOS[imagenRes]);
                    editor.putBoolean("disponible"+clave, true);

                    editor.commit();
                    Intent intent = new Intent(NuevoModificar.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }

            }
        });

    }

    private boolean verificar(){
        String nom=nombre.getText().toString();
        String tel=telefono.getText().toString();
        String apes=apellidos.getText().toString();
        String em=email.getText().toString();
        String dir=direccion.getText().toString();
        String obs=observaciones.getText().toString();
        String ap=apodo.getText().toString();

        if(tel!=null)tel=tel.trim();
        if(nom!=null)nom=nom.trim();
        if(apes!=null)apes=apes.trim();
        if(em!=null)em=em.trim();
        if(dir!=null)dir=dir.trim();
        if(obs!=null)obs=obs.trim();
        if(ap!=null)ap=ap.trim();
        if(nom.equals("")){
            Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show();
            return false;
        }
        try{
            int aux=Integer.parseInt(tel);
            if(aux<0){
                Toast.makeText(this, "El formato del telefono no es correcto", Toast.LENGTH_SHORT).show();
                return false;
            }
        }catch(Exception e){
            Toast.makeText(this, "El formato del teléfono no es correcto", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(tel.length()!=9){
            Toast.makeText(this, "El teléfono ha de tener 9 números", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(nom.length()>44){
            Toast.makeText(this, "La longitud del nombre no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(apes.length()>44){
            Toast.makeText(this, "La longitud de los apellidos no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(em.length()>44){
            Toast.makeText(this, "La longitu del email no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(dir.length()>44){
            Toast.makeText(this, "La longitud de la dirección no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(obs.length()>44){
            Toast.makeText(this, "La longitud de las observaciones no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(ap.length()>44){
            Toast.makeText(this, "La longitud del apodo no puede ser mayor a 44", Toast.LENGTH_SHORT).show();
            return false;
        }


        return true;
    }


}