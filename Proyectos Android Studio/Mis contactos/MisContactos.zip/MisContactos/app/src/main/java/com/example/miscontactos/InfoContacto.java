package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class InfoContacto extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_contacto);

        if (getSupportActionBar() != null) getSupportActionBar().hide();


        listView=findViewById(R.id.listView2);

        Bundle b=getIntent().getExtras();
        int id=b.getInt("clave");

        String nombre=b.getString("nombre","default");
        String apellidos= b.getString("apellidos","default");
        String telefono=b.getString("telefono","default");
        String email=b.getString("email","default");
        String direccion=b.getString("direccion","default");
        String observaciones=b.getString("observaciones","default");
        String apodo=b.getString("apodo","default");
        int dino=b.getInt("dino",0);

        //datos del usuario ordenados
        String datos[]={nombre+ " "+apellidos, telefono, email, direccion, apodo, observaciones};
        //iconos básicos ordenados
        int imagenes[]={R.drawable.usuario,R.drawable.telefono, R.drawable.email, R.drawable.direccion, R.drawable.apodo, R.drawable.observacion};

        //
        InfoContacto.MyAdapter adapter=new InfoContacto.MyAdapter(this, datos, imagenes);
        listView.setAdapter(adapter);

        ImageView iv=findViewById(R.id.perfil);
        iv.setImageResource(dino);
        TextView tv= findViewById(R.id.nombreinfo);
        tv.setText(nombre);

        ImageView volver=findViewById(R.id.volverinfo);
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InfoContacto.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        ImageView llamar=findViewById(R.id.llamar);
        ImageView mail=findViewById(R.id.mail);

        llamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+telefono));
                startActivity(intent);
            }
        });

        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent e= new Intent(Intent.ACTION_SENDTO);
                e.setData(Uri.parse("mailto:"+email));
                e.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                e.putExtra(Intent.EXTRA_TEXT, "My Email message");
                startActivity(e);
            }
        });

    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String nombres[];
        int dinos[];

        MyAdapter(Context c, String nombres[],int dinos[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.dinos=dinos;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row2, parent, false);

            ImageView im=row.findViewById(R.id.image2);
            TextView nombre=row.findViewById(R.id.nombre2);

            im.setImageResource(dinos[position]);
            nombre.setText(nombres[position]);

            if(nombres[position].length()>18)nombre.setTextSize(18f);
            if(nombres[position].length()>20)nombre.setTextSize(16f);

            return row;
        }
    }
}