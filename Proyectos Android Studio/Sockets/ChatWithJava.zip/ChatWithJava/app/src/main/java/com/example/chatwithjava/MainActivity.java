package com.example.chatwithjava;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText msg, inputIP;
    private ListView listView;
    private ArrayList<Boolean> recibidos;
    private ArrayList<String>mensajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.listView);

        recibidos=new ArrayList<Boolean>();
        mensajes=new ArrayList<String>();

        msg=findViewById(R.id.msg);
        inputIP=findViewById(R.id.inputIP);

        Thread myThread=new Thread(new MyServerThread());
        myThread.start();

        refreshAdapter();
    }

    public class MyServerThread implements Runnable {
        private Socket s;
        private ServerSocket ss;
        private InputStreamReader isr;
        private BufferedReader br;
        private String msg;
        private Handler h=new Handler();

        @Override
        public void run() {
            try {
                ss=new ServerSocket(7801);
                while(true){
                    s=ss.accept();
                    isr=new InputStreamReader(s.getInputStream());
                    br=new BufferedReader(isr);
                    msg= br.readLine();

                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            mensajes.add(msg);
                            recibidos.add(true);
                            refreshAdapter();
                        }
                    });
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void send(View v){
       MessageSender messageSender=new MessageSender(inputIP.getText().toString(), this);
       messageSender.execute(msg.getText().toString());
       mensajes.add(msg.getText().toString());
       recibidos.add(false);
       refreshAdapter();
       msg.setText("");
    }

    private void refreshAdapter(){
        MainActivity.MyAdapter adapter=new MainActivity.MyAdapter(this, getMensajes(), getRecibidos());
        listView.setAdapter(adapter);
    }

    private boolean[]getRecibidos(){
        boolean[]toret=new boolean[recibidos.size()];
        for(int i=0;i<recibidos.size();i++){
            toret[i]=recibidos.get(i);
        }
        return toret;
    }

    private String[]getMensajes(){
        String[]toret=new String[mensajes.size()];
        for(int i=0;i<mensajes.size();i++){
            toret[i]=mensajes.get(i);
        }
        return toret;
    }

    class MyAdapter extends ArrayAdapter<String> {
        private String mensajes[];
        private boolean recibido[];


        MyAdapter(Context c, String mensajes[], boolean recibido[]){
            super(c, R.layout.message, R.id.texto,mensajes);
            this.mensajes=mensajes;
            this.recibido=recibido;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.message, parent, false);

            LinearLayout ll=row.findViewById(R.id.ll);
            TextView tv=row.findViewById(R.id.texto);
            tv.setText(mensajes[position]);


            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            layoutParams.setMargins(60, 0, 0, 0);


            if(!recibido[position]){
                ll.setLayoutParams(layoutParams);
                ll.setBackgroundResource(R.drawable.send);
            }

            tv.setText(mensajes[position]);

            return row;
        }
    }
}