package com.example.chatwithjava;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class MessageSender extends AsyncTask<String, Void, Void> {
    private String ip;
    private Socket s;
    private DataOutputStream dos;
    private PrintWriter pw;
    private Context context;

    public MessageSender(String ip, Context context) {
        this.ip=ip;
        this.context=context;
    }

    @Override
    protected Void doInBackground(String... voids) {
        String message = voids[0];

        try {
            s=new Socket(ip, 7800);
            pw=new PrintWriter(s.getOutputStream());
            pw.write(message);
            pw.flush();
            pw.close();

        } catch (IOException e) {
            Toast.makeText(context, "Error al conectar con el pc. Comprueba la IP", Toast.LENGTH_SHORT).show();
        }

        return null;
    }
}
