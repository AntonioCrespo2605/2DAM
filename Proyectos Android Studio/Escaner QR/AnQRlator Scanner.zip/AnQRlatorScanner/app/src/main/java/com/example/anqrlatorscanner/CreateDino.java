package com.example.anqrlatorscanner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.File;
import java.io.FileOutputStream;

public class CreateDino extends AppCompatActivity {

    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_dino);

        getSupportActionBar().hide();

        Bundle parametros = this.getIntent().getExtras();
        boolean qr= parametros.getBoolean("qr");

        Button generar = findViewById(R.id.generar_btn);

        EditText palabra = findViewById(R.id.palabra);
        EditText numeros=findViewById(R.id.numeros);

        TextView titulo=findViewById(R.id.titulo);

        ImageView qr_imagen = findViewById(R.id.qr_image);
        ImageView volver2=findViewById(R.id.volver2);
        ImageView compartir=findViewById(R.id.compartir);
        ImageView descargar=findViewById(R.id.descargar_qr);

        if(!qr){
            titulo.setText("Write here your barcode");
            palabra.setVisibility(View.INVISIBLE);
            numeros.setVisibility(View.VISIBLE);
            generar.setText("Generate barcode");
        }

        generar.setOnClickListener(v -> {

            String myText;

            if(qr){
                myText = palabra.getText().toString().trim();
                if (!myText.equals("")){
                    MultiFormatWriter mWriter = new MultiFormatWriter();

                    try {
                        BitMatrix mMatrix = mWriter.encode(myText, BarcodeFormat.QR_CODE, 255, 255);
                        BarcodeEncoder mEncoder = new BarcodeEncoder();
                        bitmap = mEncoder.createBitmap(mMatrix);
                        qr_imagen.setImageBitmap(bitmap);
                        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        manager.hideSoftInputFromWindow(palabra.getApplicationWindowToken(), 0);
                        compartir.setVisibility(View.VISIBLE);
                        descargar.setVisibility(View.VISIBLE);
                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                }else Toast.makeText(CreateDino.this, "The edit text is empty", Toast.LENGTH_SHORT).show();
            }else{

                myText=numeros.getText().toString().trim();
                if(!myText.equals("")) {
                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try {

                        BitMatrix bitMatrix = multiFormatWriter.encode(myText, BarcodeFormat.CODE_128, qr_imagen.getWidth(), qr_imagen.getHeight());
                        bitmap = Bitmap.createBitmap(qr_imagen.getWidth(), qr_imagen.getHeight(), Bitmap.Config.RGB_565);
                        for (int i = 0; i < qr_imagen.getWidth(); i++) {
                            for (int j = 0; j < qr_imagen.getHeight(); j++) {
                                bitmap.setPixel(i, j, bitMatrix.get(i, j) ? Color.BLACK : Color.WHITE);
                            }
                        }
                        qr_imagen.setImageBitmap(bitmap);
                        compartir.setVisibility(View.VISIBLE);
                        descargar.setVisibility(View.VISIBLE);

                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                }else Toast.makeText(CreateDino.this, "The edit text is empty", Toast.LENGTH_SHORT).show();
            }
        });

        volver2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateDino.this, Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        descargar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveImageInGallery(bitmap, "anQRlator Scanner", "This is a code genereted by anQRlator Scanner");
                Toast.makeText(CreateDino.this, "saved on gallery", Toast.LENGTH_SHORT).show();
            }
        });

        compartir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable drawable=qr_imagen.getDrawable();
                Bitmap bitmap=((BitmapDrawable)drawable).getBitmap();

                try {
                    File file = new File(getApplicationContext().getExternalCacheDir(), File.separator +"anQRlator.jpg");
                    FileOutputStream fOut = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.flush();
                    fOut.close();
                    file.setReadable(true, false);
                    final Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    Uri photoURI = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID +".provider", file);

                    intent.putExtra(Intent.EXTRA_STREAM, photoURI);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.setType("image/jpg");

                    startActivity(Intent.createChooser(intent, "Share image via"));
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        });

    }

    private void saveImageInGallery(Bitmap yourBitmap, String yourTitle, String yourDescription){
        MediaStore.Images.Media.insertImage(getContentResolver(), yourBitmap, yourTitle , yourDescription);
    }


}