package com.example.anqrlatorscanner;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


public class ReadQR extends AppCompatActivity {

    TextView txtResultado;
    ImageView copiar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_qr);

        getSupportActionBar().hide();

        txtResultado=findViewById(R.id.txtResultado);

        ImageView camara=findViewById(R.id.camara);
        ImageView volver=findViewById(R.id.volver);
        copiar=findViewById(R.id.copiar);

        camara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                escanearQR();
            }
        });

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ReadQR.this, Menu.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        copiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("TextView", txtResultado.getText().toString());
                clipboard.setPrimaryClip(clip);

                Toast.makeText(ReadQR.this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });

    }

    //Método para escanearQR
    public void escanearQR() {
        IntentIntegrator integrador = new IntentIntegrator(this);
        integrador.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES); //PRODUCT_CODE_TYPES);
        integrador.setPrompt("Escanear Código");
        integrador.setCameraId(0);
        integrador.setBeepEnabled(true);
        integrador.setBarcodeImageEnabled(true);
        integrador.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult resultado = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (resultado != null) {
            if (resultado.getContents() == null) {
                Toast.makeText(this, "Cancelado", Toast.LENGTH_LONG).show();
            } else {
                txtResultado.setText(resultado.getContents().toString());
                copiar.setVisibility(View.VISIBLE);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


}