package com.example.erp.controller;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.erp.dataBaseObjects.Customer;
import com.example.erp.dataBaseObjects.Employee;
import com.example.erp.dataBaseObjects.Product;
import com.example.erp.dataBaseObjects.ProductSale;
import com.example.erp.dataBaseObjects.Salary;
import com.example.erp.dataBaseObjects.Sale;
import com.example.erp.dataBaseObjects.ShoppingCart;
import com.example.erp.dataBaseObjects.Supplie;
import com.example.erp.dataBaseObjects.Supplier;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    //db info
    private static final String DB_NAME="dinosDB.sqlite";
    private static int DB_VERSION=1;

    //table names
    private static final String SUPPLIER_TABLE="supplier";
    private static final String SUPPLIE_TABLE="supplie";
    private static final String PRODUCT_TABLE="product";
    private static final String PRODUCT_SUPPLIE_TABLE="product_supplie";
    private static final String SALE_TABLE="sale";
    private static final String PRODUCT_SALE_TABLE="product_table";
    private static final String EMPLOYEE_TABLE="employee";
    private static final String SALARY_TABLE="salary";
    private static final String CUSTOMER_TABLE="customer";
    private static final String SHOPPING_CART="shopping_cart";

    //controllers
    private ArrayList<Customer>customers;
    private ArrayList<Employee>employees;
    private ArrayList<Product>products;
    private ArrayList<Supplie>supplies;
    private ArrayList<Supplier>suppliers;
    private ArrayList<Sale>sales;

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create table supplier
        String queryTable="CREATE TABLE "+SUPPLIER_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL, "
                +"address TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table supplie
        queryTable="CREATE TABLE "+SUPPLIE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"id_supplier INTEGER NOT NULL REFERENCES "+SUPPLIER_TABLE+", "
                +"date TEXT NOT NULL, "
                +"state INTEGER NOT NULL,"
                +"shipping_costs TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table product
        queryTable="CREATE TABLE "+PRODUCT_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"description TEXT NOT NULL,"
                +"stock INTEGER NOT NULL,"
                +"current_price TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table product_supplier
        queryTable="CREATE TABLE "+PRODUCT_SUPPLIE_TABLE+" ("
                +"id_product INTEGER NOT NULL REFERENCES "+PRODUCT_TABLE+", "
                +"id_supplie INTEGER NOT NULL REFERENCES "+SUPPLIE_TABLE+", "
                +"amount INTEGER NOT NULL,"
                +"ind_price TEXT NOT NULL,"
                +"PRIMARY KEY(id_product, id_supplie));";

        db.execSQL(queryTable);

        //Create table employee
        queryTable="CREATE TABLE "+EMPLOYEE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"dni TEXT NOT NULL,"
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL,"
                +"workstation TEXT NOT NULL,"
                +"bank_number TEXT NOT NULL, "
                +"current_salary TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table salary
        queryTable="CREATE TABLE "+SALARY_TABLE+" ("
                +"date TEXT NOT NULL, "
                +"id_employee INTEGER NOT NULL REFERENCES "+EMPLOYEE_TABLE+", "
                +"salary TEXT NOT NULL, "
                +"PRIMARY KEY(date, id_eployee));";

        db.execSQL(queryTable);

        //Create table customer
        queryTable="CREATE TABLE "+CUSTOMER_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL,"
                +"email TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table sale
        queryTable="CREATE TABLE "+SALE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"date TEXT NOT NULL,"
                +"shipping_costs TEXT NOT NULL, "
                +"state INTEGER NOT NULL,"
                +"id_employee INTEGER NOT NULL REFERENCES "+EMPLOYEE_TABLE+", "
                +"id_customer INTEGER NOT NULL REFERENCES "+CUSTOMER_TABLE+");";

        db.execSQL(queryTable);

        //Create table product_sale
        queryTable="CREATE TABLE "+PRODUCT_SALE_TABLE+" ("
                +"id_product INTEGER NOT NULL REFERENCES "+PRODUCT_TABLE+", "
                +"id_sale INTEGER NOT NULL REFERENCES "+SALE_TABLE+", "
                +"amount INTEGER NOT NULL,"
                +"ind_price INTEGER NOT NULL,"
                +"PRIMARY KEY(sale, id_product));";

        db.execSQL(queryTable);

        //Create table shopping cart
        queryTable="CREATE TABLE "+SHOPPING_CART+" ("
                +"id_product INTEGER NOT NULL REFERENCES "+PRODUCT_TABLE+", "
                +"id_customer INTEGER NOT NULL REFERENCES "+CUSTOMER_TABLE+", "
                +"cant INTEGER NOT NULL, "
                +"PRIMARY KEY(id_product, id_customer));";

        db.execSQL(queryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+PRODUCT_SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+EMPLOYEE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+CUSTOMER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+PRODUCT_SUPPLIE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SUPPLIE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+PRODUCT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SUPPLIER_TABLE);

        onCreate(db);
    }

    /************************************************************************/
    public DBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
        readDB();
    }

    /************************************************************************/
    private void readDB(){
        readCustomers();
        readSupplier();
        readProduct();
        readEmployees();
        readSupplies();
        readSales();
    }

    private void readCustomers(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+CUSTOMER_TABLE, null);
        Cursor cursor2;

        if(cursor.moveToFirst()){
            do{
                Customer customer=(new Customer(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
                cursor2=db.rawQuery("SELECT * FROM "+SHOPPING_CART+" WHERE id_costumer="+cursor.getInt(0), null);
                ShoppingCart shoppingCart=new ShoppingCart();
                if(cursor2.moveToFirst()){
                    do{
                        shoppingCart.addProduct(getProductById(cursor2.getInt(0)), cursor2.getInt(2));
                    }while(cursor2.moveToNext());
                }
                customer.setShoppingCart(shoppingCart);
                customers.add(customer);
            }while(cursor.moveToNext());
        }
    }

    private void readSupplier(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+SUPPLIER_TABLE, null);

        if(cursor.moveToFirst()){
            do{
                suppliers.add(new Supplier(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
            }while(cursor.moveToNext());
        }
    }

    private void readProduct(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+PRODUCT_TABLE, null);

        if(cursor.moveToFirst()){
            do{
                double current_price=Double.parseDouble(cursor.getString(4));
                products.add(new Product(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3),current_price));
            }while(cursor.moveToNext());
        }
    }

    private void readEmployees(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+EMPLOYEE_TABLE, null);
        Cursor cursor2;

        if(cursor.moveToFirst()){
            do{
                Employee employee=new Employee(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                        cursor.getString(4), cursor.getString(5), Double.parseDouble(cursor.getString(6)));

                cursor2=db.rawQuery("SELECT * FROM "+SALARY_TABLE+" WHERE id_employee="+cursor.getInt(0), null);
                ArrayList<Salary>salaries=new ArrayList<Salary>();
                if(cursor2.moveToFirst()){
                    do{
                        salaries.add(new Salary(Double.parseDouble(cursor2.getString(2)),cursor2.getString(0)));
                    }while (cursor2.moveToNext());
                }
                employee.setSalaries(salaries);
                employees.add(employee);

            }while(cursor.moveToNext());
        }
    }

    private void readSupplies(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+SUPPLIE_TABLE, null);
        Cursor cursor2;

        if(cursor.moveToFirst()){
            do{
                boolean state;
                if(cursor.getInt(3)==0)state=false;
                else state=true;
                Supplie supplie=new Supplie(cursor.getInt(0), getSupplierById(cursor.getInt(1)), cursor.getString(2), state, Double.parseDouble(cursor.getString(4)));

                cursor2=db.rawQuery("SELECT * FROM "+PRODUCT_SUPPLIE_TABLE+" WHERE id_supplie="+cursor.getInt(0), null);
                ArrayList<ProductSale>lines=new ArrayList<ProductSale>();
                if(cursor2.moveToFirst()){
                    do{
                        lines.add(new ProductSale(getProductById(cursor2.getInt(0)), cursor2.getInt(2), Double.parseDouble(cursor2.getString(3))));
                    }while (cursor2.moveToNext());
                }
                supplie.setLines(lines);
                supplies.add(supplie);

            }while(cursor.moveToNext());
        }
    }

    private void readSales(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+SALE_TABLE, null);
        Cursor cursor2;

        if(cursor.moveToFirst()){
            do{
                boolean state;
                if(cursor.getInt(3)==0)state=false;
                else state=true;

                Sale sale=new Sale(cursor.getInt(0),cursor.getString(1),Double.parseDouble(cursor.getString(2)),state, getEmployeeById(cursor.getInt(4)), getCustomerById(cursor.getInt(5)));
                cursor2=db.rawQuery("SELECT * FROM "+PRODUCT_SALE_TABLE+" WHERE id_sale="+cursor.getInt(0), null);
                ArrayList<ProductSale>lines=new ArrayList<ProductSale>();
                if(cursor2.moveToFirst()){
                    do{
                        lines.add(new ProductSale(getProductById(cursor2.getInt(0)), cursor2.getInt(2), Double.parseDouble(cursor2.getString(3))));
                    }while (cursor2.moveToNext());
                }
                sale.setLines(lines);
                sales.add(sale);
            }while(cursor.moveToNext());
        }
    }


    /************************************************************************/
    //information filters

    private Supplier getSupplierById(int id){
        for(Supplier supplier:suppliers){
            if(supplier.getId()==id)return supplier;
        }
        return null;
    }

    private Product getProductById(int id){
        for(Product product:products){
            if(product.getId()==id)return product;
        }
        return null;
    }

    private Employee getEmployeeById(int id){
        for(Employee employee:employees){
            if(employee.getId()==id)return employee;
        }
        return null;
    }

    private Customer getCustomerById(int id){
        for(Customer customer:customers){
            if(customer.getId()==id)return customer;
        }
        return null;
    }

    /************************************************************************/
    //adding Methods

    public void addCustomer(Customer customer){
        int id=1;
        while(existsCustomer(id)){
            id++;
        }
    }

    public void addEmlployee(Employee employee){
        int id=1;
        while(existsEmployee(id)){
            id++;
        }
    }

    public void addProduct(Product product){
        int id=1;
        while(existsProduct(id)){
            id++;
        }
    }

    public void addSupplie(Supplie supplie){
        int id=1;
        while(existsSupplie(id)){
            id++;
        }
    }
    public void addSupplier(Supplier supplier){
        int id=1;
        while(existsSupplier(id)){
            id++;
        }
    }

    public void addSale(Sale sale){
        int id=1;
        while(existsSale(id)){
            id++;
        }
    }

    /************************************************************************/
    //check if exists

    private boolean existsCustomer(int id){
        for(Customer customer:customers){
            if(customer.getId()==id)return true;
        }
        return false;
    }

    private boolean existsEmployee(int id){
        for(Employee employee:employees){
            if(employee.getId()==id)return true;
        }
        return false;
    }

    private boolean existsProduct(int id){
        for(Product product:products){
            if(product.getId()==id)return true;
        }
        return false;
    }

    private boolean existsSupplie(int id){
        for(Supplie supplie:supplies){
            if(supplie.getId()==id)return true;
        }
        return false;
    }

    private boolean existsSupplier(int id){
        for(Supplier supplier:suppliers){
            if(supplier.getId()==id)return true;
        }
        return false;
    }

    private boolean existsSale(int id){
        for(Sale sale:sales){
            if(sale.getId()==id)return true;
        }
        return false;
    }

}
