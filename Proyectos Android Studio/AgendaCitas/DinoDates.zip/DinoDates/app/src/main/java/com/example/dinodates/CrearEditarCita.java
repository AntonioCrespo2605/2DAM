package com.example.dinodates;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;

public class CrearEditarCita extends AppCompatActivity {

    private ImageView derecha, izquierda, img, calendario, reloj, fecha, hora, volver;
    private TextView f, h;
    private FloatingActionButton crear;
    private EditText asunto, descripcion;
    private int posImg=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_editar_cita);

        derecha=findViewById(R.id.derechaCrear);
        izquierda=findViewById(R.id.izquierdaCrear);
        img=findViewById(R.id.imagenCrear);
        calendario=findViewById(R.id.calendarioCrear);
        reloj=findViewById(R.id.relojCrear);
        fecha=findViewById(R.id.fechaCrear);
        hora=findViewById(R.id.fechaCrear);
        f=findViewById(R.id.fCrear);
        h=findViewById(R.id.hCrear);
        crear=findViewById(R.id.crear);
        asunto=findViewById(R.id.asuntoCrear);
        descripcion=findViewById(R.id.descripcionCrear);
        volver=findViewById(R.id.volverCrear);

        DBHandler handler=new DBHandler(this);

        int[]imagenes={R.drawable.bebe, R.drawable.calendario, R.drawable.chef, R.drawable.coche, R.drawable.comida, R.drawable.corazon, R.drawable.corbata, R.drawable.cumple, R.drawable.dinosaurio, R.drawable.interrogacion, R.drawable.llave, R.drawable.mando, R.drawable.medico, R.drawable.pastis, R.drawable.pc, R.drawable.peligro, R.drawable.pesas, R.drawable.reloj, R.drawable.tele, R.drawable.telefono, R.drawable.tijeras, R.drawable.ubicacion, R.drawable.usuario};

        Bundle b = getIntent().getExtras();
        boolean editar = b.getBoolean("editar", false);
        int id=b.getInt("id",0);
        if(editar){
            Cita c=handler.getCitaById(id);
            img.setImageResource(c.getImagen());
            f.setText(c.getFecha());
            h.setText(c.getHora());
            asunto.setText(c.getTitulo());
            descripcion.setText(c.getDescripcion());

            for(int i=0;i<imagenes.length;i++){
                if(imagenes[i]==c.getImagen()){
                    posImg=i;
                    break;
                }
            }
        }else{
            f.setText("");
            h.setText("");
        }


        //boton de crear o editar
        crear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        //Botones derecha e izquierda
        derecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posImg+=1;
                if(posImg>=imagenes.length)posImg=0;
                img.setImageResource(imagenes[posImg]);
            }
        });

        izquierda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                posImg--;
                if(posImg<0)posImg=imagenes[imagenes.length-1];
                img.setImageResource(imagenes[posImg]);
            }
        });

        //boton de calendario:
        calendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
                String fecha= datePicker.getString(0);
                System.out.println(fecha);
            }
        });

        //boton de volver
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CrearEditarCita.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

    }
}