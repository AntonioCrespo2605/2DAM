package com.example.dinodates;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private ListView lv;
    private DBHandler handler;

    private FloatingActionButton expandir, anhadir, modificar, eliminar;

    private boolean modoBorrar=false, modoEditar=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        lv=findViewById(R.id.listView);
        handler=new DBHandler(this);

        expandir=findViewById(R.id.expandir);
        anhadir=findViewById(R.id.anhadir);
        modificar=findViewById(R.id.editar);
        eliminar=findViewById(R.id.eliminar);

        addDefaultCitas();

        MyAdapter adapter=new MyAdapter(this, handler.getTitulos(), handler.getImagenes(), handler.getFechas(), handler.getHoras());
        lv.setAdapter(adapter);


        //BOTONES FLOTANTES
        //expandir
        expandir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(modificar.getVisibility()==View.VISIBLE){
                    modificar.setVisibility(View.INVISIBLE);
                    eliminar.setVisibility(View.INVISIBLE);
                    anhadir.setVisibility(View.INVISIBLE);
                }else{
                    modificar.setVisibility(View.VISIBLE);
                    eliminar.setVisibility(View.VISIBLE);
                    anhadir.setVisibility(View.VISIBLE);
                }
            }
        });

        //borrar boton
        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(modoBorrar){
                    modoBorrar=false;
                    modoEditar=false;
                    eliminar.setImageResource(R.drawable.ic_baseline_delete_forever_24);
                    modificar.setImageResource(R.drawable.ic_baseline_edit_note_24);
                    lv.setBackgroundColor(getResources().getColor(R.color.azulFondo));
                }else{
                    modoBorrar=true;
                    modoEditar=false;
                    eliminar.setImageResource(R.drawable.ic_baseline_cancel_24);
                    modificar.setImageResource(R.drawable.ic_baseline_edit_note_24);
                    lv.setBackgroundColor(getResources().getColor(R.color.rojoFondo));
                }
                modificar.setVisibility(View.INVISIBLE);
                eliminar.setVisibility(View.INVISIBLE);
                anhadir.setVisibility(View.INVISIBLE);
            }
        });

        //editar boton
        modificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(modoEditar){
                    modoBorrar=false;
                    modoEditar=false;
                    eliminar.setImageResource(R.drawable.ic_baseline_delete_forever_24);
                    modificar.setImageResource(R.drawable.ic_baseline_edit_note_24);
                    lv.setBackgroundColor(getResources().getColor(R.color.azulFondo));
                }else{
                    modoBorrar=false;
                    modoEditar=true;
                    eliminar.setImageResource(R.drawable.ic_baseline_delete_forever_24);
                    modificar.setImageResource(R.drawable.ic_baseline_cancel_24);
                    lv.setBackgroundColor(getResources().getColor(R.color.naranjaFondo));
                }
                modificar.setVisibility(View.INVISIBLE);
                eliminar.setVisibility(View.INVISIBLE);
                anhadir.setVisibility(View.INVISIBLE);
            }
        });

        //boton anhadir
        anhadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CrearEditarCita.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("editar", false);
                intent.putExtra("id",0);
                startActivity(intent);
                finish();
            }
        });

        //CLICK EN LISTVIEW
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //si no tiene ningun modo activado
                if(!modoEditar&&!modoBorrar){
                    Intent intent = new Intent(MainActivity.this, MostrarCita.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("id", handler.getIdByPosition(position));
                    startActivity(intent);
                    finish();

                    //si tiene activado el modo editar
                }else if(modoEditar){
                    Intent intent = new Intent(MainActivity.this, CrearEditarCita.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("editar", true);
                    intent.putExtra("id", handler.getIdByPosition(position));
                    startActivity(intent);
                    finish();

                    //si tiene activado el modo borrar
                }else if(modoBorrar){
                    Cita c=handler.getCitas().get(position);
                    AlertDialog.Builder altdial = new AlertDialog.Builder(MainActivity.this);
                    altdial.setMessage("Estás a punto de eliminar el evento "+c.getTitulo()+" del "+c.getFecha()+" a las "+c.getHora()+"\n¿Estás segur@?").setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    handler.deleteCita(handler.getIdByPosition(position));
                                    MyAdapter adapter=new MyAdapter(MainActivity.this, handler.getTitulos(), handler.getImagenes(), handler.getFechas(), handler.getHoras());
                                    lv.setAdapter(adapter);
                                    eliminar.setImageResource(R.drawable.ic_baseline_delete_forever_24);
                                    modoBorrar=false;
                                    lv.setBackgroundColor(getResources().getColor(R.color.azulFondo));
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    eliminar.setImageResource(R.drawable.ic_baseline_delete_forever_24);
                                    modoBorrar=false;
                                    lv.setBackgroundColor(getResources().getColor(R.color.azulFondo));
                                }
                            });

                    AlertDialog alert = altdial.create();
                    alert.setTitle("Atención");
                    alert.show();
                }
            }
        });

    }
    /**-------------------------------------------------------------------------------------------------------------------------------------**/
    //Adaptador
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String titulos[];
        int imagenes[];
        String fechas[];
        String horas[];

        MyAdapter(Context c, String titulos[],int imagenes[], String fechas[], String[]horas){
            super(c, R.layout.row, R.id.titulo,titulos);
            this.context=c;
            this.titulos=titulos;
            this.fechas=fechas;
            this.horas=horas;
            this.imagenes=imagenes;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);

            ImageView img=row.findViewById(R.id.icono);
            ImageView estado=row.findViewById(R.id.estado);
            TextView titulo=row.findViewById(R.id.titulo);
            TextView fh=row.findViewById(R.id.fecha);


            img.setImageResource(imagenes[position]);
            titulo.setText(titulos[position]);
            fh.setText(getCustomDay(fechas[position])+" "+horas[position]);


            if(isLate(fechas[position]+" "+horas[position], fechaHoraActual())){
                estado.setImageResource(R.drawable.rojo);
            }else if(fechas[position].equals(fechaActual())){
                estado.setImageResource(R.drawable.naranja);
            }else {
                estado.setImageResource(R.drawable.verde);
            }
            return row;
        }

        @Override
        public int getViewTypeCount(){
            return getCount();
        }

        @Override
        public int getItemViewType(int position){
            return position;
        }
    }
    /**-------------------------------------------------------------------------------------------------------------------------------------**/
    //FUNCIONES AUXILIARES

    //devuelve la fecha y la hora con el formato especificado como una String
    private static String fechaHoraActual() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String date = dateFormat.format(new Date());

        return date;
    }

    //devuelve la fecha actual
    private static String fechaActual() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String date = dateFormat.format(new Date());

        return date;
    }

    //devuelve el día de ayer
    public String fechaAyer() {
        Date today = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        Date yesterday = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String yesterdayFormatted = dateFormat.format(yesterday);

        return yesterdayFormatted;
    }

    public String fechaPasadoManhana(){
        Date today = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DAY_OF_YEAR, 2);
        Date pasado = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String pasadomanhana = dateFormat.format(pasado);

        return pasadomanhana;
    }

    public String fechaManhana(){
        Date today = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String tomorrowFormatted = dateFormat.format(tomorrow);

        return tomorrowFormatted;
    }

    //devuelve true si la segunda fecha es anterior a la primera
    private static boolean isLate(String f1, String f2) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        try{
            Date d1= formato.parse(f1);
            Date d2= formato.parse(f2);
            if(d1.after(d2))return false;
            else return true;
        }catch(ParseException e){
            return false;
        }
    }

    //Devuelve la fecha correspondiente a los valores "Hoy", "Mañana", "Pasado mañana" o "Ayer" o en su defecto la misma fecha
    private static String getCustomDay(String fecha){
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        if(fecha.equals(fechaActual()))return "Hoy";

        Date f=null,fActual=null;
        try{
            f= formato.parse(fecha);
            fActual= formato.parse(fechaActual());
        }catch (Exception e){
            return fecha;
        }

        Calendar calendar=Calendar.getInstance();
        calendar.setTime(f);

        int diaFecha=calendar.get(Calendar.DAY_OF_MONTH);
        int mesFecha=calendar.get(Calendar.MONTH)+1;
        int anhoFecha=calendar.get(Calendar.YEAR);

        calendar=Calendar.getInstance();
        calendar.setTime(fActual);

        int diaActual=calendar.get(Calendar.DAY_OF_MONTH);
        int mesActual=calendar.get(Calendar.MONTH)+1;
        int anhoActual=calendar.get(Calendar.YEAR);

        if(anhoActual-anhoFecha>1 ||anhoFecha-anhoActual>1)return fecha;

        if(anhoActual==anhoFecha && mesActual==mesFecha){
            if(diaActual==diaFecha+1)return "Ayer";
            else if(diaActual==diaFecha-1)return "Mañana";
            else if(diaActual==diaFecha-2)return "Pasado mañana";
            else return fecha;
        }

        if(anhoActual==anhoFecha){
            if(mesActual==mesFecha+1){
                if(diaActual==1&&diaFecha==getNumDays(mesFecha,anhoFecha))return "Ayer";
                else return fecha;
            }else if(mesFecha==mesActual+1){
                if(diaActual==getNumDays(mesActual, anhoActual)){
                    if(diaFecha==1)return "Mañana";
                    else if(diaFecha==2)return "Pasado mañana";
                    else return fecha;
                }else if(diaActual==getNumDays(mesActual, anhoActual)-1){
                    if(diaFecha==1)return "Pasado mañana";
                    else return fecha;
                }
            }else return fecha;
        }else if(anhoFecha==anhoActual+1){
            if(mesActual==12){
                if(diaActual==31){
                    if(mesFecha==1){
                        if(diaFecha==1)return "Mañana";
                        if(diaFecha==2)return "Pasado mañana";
                    }else return fecha;
                }else if(diaActual==30){
                    if(diaFecha==1)return "Pasado mañana";
                    else return fecha;
                } else return fecha;
            }else return fecha;
        }else if(anhoActual==anhoFecha+1){
            if(mesActual==1&&mesFecha==12){
                if(diaActual==1&&mesFecha==31)return "Ayer";
                else return fecha;
            }else return fecha;
        }
        return fecha;
    }

    private static boolean esBisiesto(int anho) {
        if (anho % 4 == 0 && anho % 100 != 0 || anho % 400 == 0)return true;
        else return false;
    }

    private static int getNumDays(int mes, int anho){
        switch (mes){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            case 2:
                if(esBisiesto(anho))return 29;
                else return 28;
        }
        return 30;
    }

    /**-------------------------------------------------------------------------------------------------------------------------------------**/
    //anhade citas por defecto
    private void addDefaultCitas(){
        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sh.edit();

        boolean iniciada=sh.getBoolean("iniciada",false);

        if(!iniciada) {
            Toast.makeText(this, "Iniciada base de datos por defecto", Toast.LENGTH_SHORT).show();
            editor.putBoolean("iniciada",true);
            editor.commit();
            //futuro lejano y mañana:
            handler.addNewCita(new Cita(1, "Dentista", "17/02/3024", "13:30", "Quitar muela por inflarse a dulces", R.drawable.medico));
            handler.addNewCita(new Cita(2, "Cumple juan", fechaManhana(), "00:00", "Comprar regalo y cumple en Churruca", R.drawable.cumple));
            handler.addNewCita(new Cita(3, "Cita", fechaPasadoManhana(), "16:00", "Cita con la moza", R.drawable.corazon));

            //hoy y hoy caducado
            handler.addNewCita(new Cita(4, "Pastel", fechaActual(), "23:59", "Sacar el pastel del horno", R.drawable.chef));
            handler.addNewCita(new Cita(5,"Duda",fechaActual(), "00:00", "Preguntar temario de programación", R.drawable.interrogacion));

            //caducadas y ayer
            handler.addNewCita(new Cita(6, "Paseo", "30/01/0001", "15:30", "Sacar a dar un paseo al dinosaurio", R.drawable.dinosaurio));
            handler.addNewCita(new Cita(7, "Renunión", "13/01/2023", "17:55","Reunión con el jefazo",R.drawable.corbata));
            handler.addNewCita(new Cita(8, "Salir a correr", fechaAyer(), "17:30", "Salir a correr como propósito de año nuevo", R.drawable.pesas));
        }
    }

    /**-------------------------------------------------------------------------------------------------------------------------------------**/



}