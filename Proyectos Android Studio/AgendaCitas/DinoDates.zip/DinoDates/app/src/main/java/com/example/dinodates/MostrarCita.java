package com.example.dinodates;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;


public class MostrarCita extends AppCompatActivity {
    private ImageView volver, qr, img;
    private TextView titulo, fecha, descripcion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_cita);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        volver=findViewById(R.id.volverMostrar);
        qr=findViewById(R.id.qrMostrar);
        img=findViewById(R.id.imagenMostrar);
        titulo=findViewById(R.id.tituloMostrar);
        fecha=findViewById(R.id.fechaMostrar);
        descripcion=findViewById(R.id.descripcionMostar);

        Bundle b = getIntent().getExtras();
        int id = b.getInt("id", 0);

        DBHandler handler=new DBHandler(this);
        Cita cita=handler.getCitaById(id);

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MostrarCita.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        titulo.setText(cita.getTitulo());
        fecha.setText(cita.getFecha()+" "+cita.getHora());
        descripcion.setText(cita.getDescripcion());
        img.setImageResource(cita.getImagen());

        qr.setImageBitmap(generateQRCode(cita.getId()+"-"+cita.getFecha()+" "+cita.getHora()+"-"+cita.getTitulo()));

    }

    public Bitmap generateQRCode(String data) {
        try {
            MultiFormatWriter writer = new MultiFormatWriter();
            BitMatrix bitMatrix = writer.encode(data, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bitmap;
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }
}