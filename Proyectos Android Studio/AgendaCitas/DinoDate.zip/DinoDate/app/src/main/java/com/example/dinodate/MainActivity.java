package com.example.dinodate;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv=findViewById(R.id.listView);

    }

    //Adaptador
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String titulos[];
        int imagenes[];
        String fecha[];
        String hora[];

        MyAdapter(Context c, String titulos[],int imagenes[], String fecha[], String[]hora){
            super(c, R.layout.row, R.id.titulo,titulos);
            this.context=c;
            this.titulos=titulos;
            this.fecha=fecha;
            this.hora=hora;
            this.imagenes=imagenes;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);

            ImageView img=row.findViewById(R.id.icono);
            ImageView estado=row.findViewById(R.id.estado);
            TextView titulo=row.findViewById(R.id.titulo);
            TextView fh=row.findViewById(R.id.fecha);


            img.setImageResource(imagenes[position]);
            titulo.setText(titulos[position]);
            fh.setText(fecha[position]+" "+hora[position]);


            /*
            LinearLayout ll=row.findViewById(R.id.layout);
            if(selected.get(position))ll.setBackgroundResource(R.drawable.rounded_edge_edit);
            else  ll.setBackgroundResource(R.drawable.rounded_edge);*/
            return row;
        }

        @Override
        public int getViewTypeCount(){
            return getCount();
        }

        @Override
        public int getItemViewType(int position){
            return position;
        }
    }

    //FUNCIONES AUXILIARES

    //devuelve la fecha y la hora con el formato especificado como una String
    private static String fechaHoraActual() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String date = dateFormat.format(new Date());

        return date;
    }

    //devuelve true si la fecha 1 es mas tarde que la 2
    private static boolean isLater(String f1, String f2) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        try{
            Date d1= formato.parse(f1);
            Date d2= formato.parse(f2);
        }catch(ParseException e){
            return false;
        }
    }
}