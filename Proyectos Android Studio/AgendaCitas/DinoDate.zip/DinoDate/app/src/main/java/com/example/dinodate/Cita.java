package com.example.dinodate;

public class Cita {
    private int id, imagen;
    private String fecha, hora, descripcion, titulo;

    public Cita(int id,String titulo ,String fecha, String hora, String descripcion, int imagen) {
        this.id = id;
        this.titulo=titulo;
        this.fecha=fecha;
        this.hora=hora;
        this.descripcion=descripcion;
        this.imagen=imagen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
