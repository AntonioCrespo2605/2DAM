package com.example.dinodate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME="citasDB";
    private static final int DB_VERSION=1;
    private static final String CITAS_TABLE_NAME="cita";

    private static final String ID_COLUMN="id";
    private static final String TITULO_COLUMN="titulo";
    private static final String FECHA_HORA_COLUMN="fecha_hora";
    private static final String IMAGEN_COLUMN="imagen";
    private static final String DESCRIPCION_COLUMN="descripcion";

    private ArrayList<Cita>citas;

    //constructor
    public DBHandler(Context context){
        super(context, DB_NAME,null, DB_VERSION);
        readCitas();
    }

    //onCreate
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query ="CREATE TABLE "+CITAS_TABLE_NAME+" ("
                +ID_COLUMN+" INTEGER PRIMARY KEY AUTOINCREMENT, "
                +TITULO_COLUMN+" TEXT NOT NULL,"
                +FECHA_HORA_COLUMN+" TEXT NOT NULL UNIQUE, "
                +IMAGEN_COLUMN+" INTEGER NOT NULL,"
                +DESCRIPCION_COLUMN+" TEXT NOT NULL)";

        db.execSQL(query);
    }

    //onUpgrade
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+CITAS_TABLE_NAME);
        onCreate(db);
    }

    //inicializa el array leyendo de la base de datos
    private void readCitas(){
        citas=new ArrayList<Cita>();

        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+CITAS_TABLE_NAME, null);

        if(cursor.moveToFirst()){
            do{
                //(id, titulo, fecha_hora, img, desc)
                String fecha_hora=cursor.getString(1);
                String fecha="";
                String hora="";
                boolean h=false;
                for(int i=0;i<fecha_hora.length();i++){
                    if(fecha_hora.charAt(i)==' ')h=true;
                    else{
                        if(h)hora+=fecha_hora.charAt(i);
                        else fecha+=fecha_hora.charAt(i);
                    }
                }
                citas.add(new Cita(cursor.getInt(0),cursor.getString(1), fecha, hora, cursor.getString(4), cursor.getInt(3)));
            }while(cursor.moveToNext());
        }
    }

    //comprueba si un id esta repetido. Devuelve true si lo está y false si no existe
    private boolean existsId(int id){
        for(int i=0;i<citas.size();i++){
            if (citas.get(i).getId()==id)return true;
        }
        return false;
    }

    //comprueba si ya existe una cita con la misma fecha
    public boolean existsFechaHora(String fecha, String hora){
        for(int i=0;i<citas.size();i++){
            if (citas.get(i).getFecha()==fecha){
                if(citas.get(i).getHora()==hora)return true;
            }
        }
        return false;
    }

    //devuelve un arrayList con las citas
    public ArrayList<Cita> getCitas(){
        return this.citas;
    }

    //añade una nueva cita a la db y al arrayList
    public void addNewCita(Cita cita){
        int id_new=1;
        while(existsId(id_new)){
            id_new++;
        }
        cita.setId(id_new);

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID_COLUMN, cita.getId());
        values.put(TITULO_COLUMN, cita.getTitulo());
        values.put(FECHA_HORA_COLUMN, cita.getFecha()+" "+cita.getHora());
        values.put(IMAGEN_COLUMN, cita.getImagen());
        values.put(DESCRIPCION_COLUMN, cita.getDescripcion());

        db.insert(CITAS_TABLE_NAME, null, values);
        db.close();

        this.citas.add(cita);
    }

    //borra una cita de la db y del arrayList dado su id
    public void deleteCita(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(CITAS_TABLE_NAME, ID_COLUMN+"="+id, null);
        db.close();

        for(int i=0;i<citas.size();i++){
            if(citas.get(i).getId()==id){
                citas.remove(i);
                break;
            }
        }
    }

    //modifica una cita dado su id y una Cita nueva
    public void updateCita(int id_old, Cita newCita){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ID_COLUMN, id_old);
        values.put(TITULO_COLUMN, newCita.getTitulo());
        values.put(FECHA_HORA_COLUMN, newCita.getFecha()+" "+newCita.getHora());
        values.put(IMAGEN_COLUMN, newCita.getImagen());
        values.put(DESCRIPCION_COLUMN, newCita.getDescripcion());

        db.update(CITAS_TABLE_NAME, values, ID_COLUMN+"="+id_old, null);
        db.close();

        int pos=-1;

        for(int i=0;i<citas.size();i++){
            if(citas.get(i).getId()==id_old){
                pos=i;
                break;
            }
        }
        if(pos!=-1)citas.set(pos, newCita);
    }
}
