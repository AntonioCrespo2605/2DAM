package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Locale;

public class Carrusel extends AppCompatActivity {

    //Imagenes
    ImageView orientacion, foto, lupa;

    //AutoCompleteTextView
    AutoCompleteTextView buscador;

    //booleano para saber la orientación. Si está a false es izquierda
    boolean derecha=true;

    //contador auxiliar para cambiar las imagenes
    int cont=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrusel);

        //ocultar actionbar
        getSupportActionBar().hide();

        //nombres de dinosaurios recogidos de strings.xml
        String[] nombres = getResources().getStringArray(R.array.dinosaurs);

        buscador = findViewById(R.id.buscador);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.dinosaur_list, R.id.text_view_list_item, nombres);
        buscador.setAdapter(adapter);

        //ints correspondientes a las imagenes de drawable
        int estego=R.drawable.estego;
        int parasaurio=R.drawable.parasaurio;
        int ptera=R.drawable.ptera;
        int rex=R.drawable.rex;
        int trike=R.drawable.trike;
        int theri=R.drawable.tericino;
        int spino=R.drawable.espinosaurio;

        //guardando los strings en un array
        int[]imagenes={estego, parasaurio, ptera, rex, trike, theri, spino};

        //definicion de imagenes
        orientacion=findViewById(R.id.orientacion);
        foto=findViewById(R.id.foto);
        lupa=findViewById(R.id.lupa);

        //definicion del buscador
        buscador=findViewById(R.id.buscador);

        //Al hacer click en las huellas se cambia la orientación y la imagen, además de notificar la nueva dirección
        orientacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(derecha){
                    derecha=false;
                    orientacion.setImageDrawable(getDrawable(R.drawable.huellas_izquierda));
                    Toast.makeText(Carrusel.this, "Orientation has changed to the left", Toast.LENGTH_SHORT).show();
                }else{
                    derecha=true;
                    orientacion.setImageDrawable(getDrawable(R.drawable.huellas_derecha));
                    Toast.makeText(Carrusel.this, "Orientation has changed to the right", Toast.LENGTH_SHORT).show();
                }
            }
        });


        //evento para cambiar de foto
        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //dependiendo del sentido accedemos a una posición distinta del array
                if(derecha)cont++;
                else cont--;

                //si llega a la dimensión del array vuelve a la primera imagen y si llega a la primera se salta a la última
                if(cont==nombres.length)cont=0;
                else if(cont==-1)cont=nombres.length-1;

                //cambiamos la foto por la correspondiente a cont y notificamos el nombre
                foto.setImageDrawable(getDrawable(imagenes[cont]));
                Toast.makeText(Carrusel.this, nombres[cont], Toast.LENGTH_SHORT).show();
            }
        });

        lupa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dino=buscador.getText().toString();
                boolean encontrado=false;
                for(int i=0;i< nombres.length;i++){
                    if(dino.toLowerCase().equals(nombres[i].toLowerCase())){
                        cont=i;
                        foto.setImageDrawable(getDrawable(imagenes[i]));
                        Toast.makeText(Carrusel.this, nombres[cont], Toast.LENGTH_SHORT).show();
                        encontrado=true;
                        break;
                    }
                }
                if(!encontrado){
                    Toast.makeText(Carrusel.this, "Dinosaur not found", Toast.LENGTH_SHORT).show();
                    buscador.setText("");
                }
            }
        });

    }
}