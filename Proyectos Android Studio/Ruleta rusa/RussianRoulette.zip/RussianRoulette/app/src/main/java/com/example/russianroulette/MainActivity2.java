package com.example.russianroulette;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import java.util.Random;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity2 extends AppCompatActivity {

    int cont=6;
    boolean activatedAnim=false;
    boolean aliveP1=true;
    boolean activatedTouch=true;
    int randomBullet=1;
    int numPlayers=1;
    int mortalBullets=1;
    ImageView mbp, bulletclue, charger, trigger, light, txtmain, txtsw;
    boolean[]alivePlayers;
    boolean[]clues;
    int turn=1;
    GifImageView anim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Bundle b=this.getIntent().getExtras();
        numPlayers=b.getInt("players");
        mortalBullets=b.getInt("difficulty");

        bulletclue=findViewById(R.id.balapista);
        mbp=findViewById(R.id.balas);
        charger=findViewById(R.id.cargador);
        trigger=findViewById(R.id.gatillo);
        light=findViewById(R.id.bombilla);
        txtmain=findViewById(R.id.txtmain);
        txtsw=findViewById(R.id.sw);

        bulletclue.setVisibility(View.INVISIBLE);
        txtMortalBullets();
        alivePlayersTrue();
        setRandomBullet();

        anim=findViewById(R.id.anim2);

        if(numPlayers==1)txtmain.setImageDrawable(getDrawable(R.drawable.r6));

        charger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(activatedTouch){
                    activatedTouch=false;
                    setRandomBullet();
                    bulletclue.setVisibility(View.INVISIBLE);
                    reloadinganim();
                }
            }
        });

        trigger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(activatedTouch){
                    bulletclue.setVisibility(View.INVISIBLE);
                    activatedTouch=false;
                    if(randomBullet>mortalBullets){//si ganas el turno
                        cont --;
                        animSave();
                    }else {//si pierdes el turno
                        aliveP1=false;
                        alivePlayers[turn - 1] = false;
                        animFail();
                    }
                }
            }
        });

        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(activatedTouch){
                    light.setVisibility(View.INVISIBLE);
                    clues[turn-1]=false;
                    bulletclue.setVisibility(View.VISIBLE);
                    if(randomBullet>mortalBullets)bulletclue.setImageDrawable(getDrawable(R.drawable.balablanca));
                    else bulletclue.setImageDrawable(getDrawable(R.drawable.balaroja));
                }
            }
        });

        //for skipping animations if they are too long
        anim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(activatedAnim){

                }
            }
        });

    }

    //change the text down "mortal bullets"
    private void txtMortalBullets(){
        switch (mortalBullets){
            case 1:mbp.setImageDrawable(getDrawable(R.drawable.b16));
                break;
            case 2:mbp.setImageDrawable(getDrawable(R.drawable.b26));
                break;
            case 3:mbp.setImageDrawable(getDrawable(R.drawable.b36));
                break;
            case 4:mbp.setImageDrawable(getDrawable(R.drawable.b46));
                break;
            case 5:mbp.setImageDrawable(getDrawable(R.drawable.b56));
                break;
        }
    }

    //starts the alivePlayers array and all of them are true as their clues
    private void alivePlayersTrue(){
        alivePlayers=new boolean[numPlayers];
        clues=new boolean[numPlayers];

        for(int i=0;i<numPlayers;i++){
            alivePlayers[i]=true;
            clues[i]=true;
        }
    }

    //change the Player turn
    private void nextTurn(){
        checkWin();

        boolean repeat=true;
        do{
            turn++;
            if(turn>numPlayers)turn=1;
            if(alivePlayers[turn-1])repeat=false;
            if(numPlayers==1)repeat=false;
        }while(repeat);

        setRandomBullet();

        if(clues[turn-1])light.setVisibility(View.VISIBLE);
        else light.setVisibility(View.INVISIBLE);

        //if there are more players you must add more cases with more drawable tjx
        switch(turn){
            case 1:
                if(numPlayers>1)txtmain.setImageDrawable(getDrawable(R.drawable.tj1));
                else turnCounter();
                break;
            case 2:txtmain.setImageDrawable(getDrawable(R.drawable.tj2));
                break;
            case 3:txtmain.setImageDrawable(getDrawable(R.drawable.tj3));
                break;
            default:txtmain.setImageDrawable(getDrawable(R.drawable.tjx));
                break;
        }
    }

    //only for 1 player. Change the remaining turns
    private void turnCounter(){
        switch(cont){
            case 6:txtmain.setImageDrawable(getDrawable(R.drawable.r6));
                break;
            case 5:txtmain.setImageDrawable(getDrawable(R.drawable.r5));
                break;
            case 4:txtmain.setImageDrawable(getDrawable(R.drawable.r4));
                break;
            case 3:txtmain.setImageDrawable(getDrawable(R.drawable.r3));
                break;
            case 2:txtmain.setImageDrawable(getDrawable(R.drawable.r2));
                break;
            case 1:txtmain.setImageDrawable(getDrawable(R.drawable.r1));
                break;
        }
    }

    //generates a random bullet value between 1 and 6 included
    private void setRandomBullet(){
        Random r=new Random();
        randomBullet=1+r.nextInt(6);
    }

    //If there is only one player checks that you win in all tries and if there are more than one player check if there is only one alive to change the activity
    private void checkWin(){
        if(numPlayers==1){//one player checker
            if(aliveP1==false){

                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("numPlayers",numPlayers);
                intent.putExtra("victory",false);
                startActivity(intent);
                finish();
            }else{
                if(cont==0){

                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("numPlayers",numPlayers);
                    intent.putExtra("victory",true);
                    intent.putExtra("difficulty",mortalBullets);
                    startActivity(intent);
                    finish();
                }
            }


        }else{//more than one player checker
            int contAlives=0;
            for(int i=0;i<alivePlayers.length;i++){
                if(alivePlayers[i])contAlives++;
            }

            if(contAlives<=1){
                int posWin=0;
                for(int i=0;i<alivePlayers.length;i++){
                    if(alivePlayers[i]){
                        posWin=1+i;
                        break;
                    }
                }
                winner(posWin);
            }
        }
    }

    private void winner(int posWin){
        Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("numPlayers",numPlayers);
        intent.putExtra("posWinner",posWin);
        startActivity(intent);
        finish();
    }

//Fail animations
//------------------------------------------------------------
    private void animFail(){//random animation
        txtsw.setVisibility(View.VISIBLE);
        txtsw.setImageDrawable(getDrawable(R.drawable.wasted));

        Random r=new Random();
        int nr=r.nextInt(2);//this number must be the fail animations you have. To add more increase the number and add the corresponding code in the switch case;

        switch(nr){
            case 0:animFail0();
                break;
            case 1:animFail1();
                break;

            /*case x:animFailx();
              break;
            */
        }

    }

    private void animFail0(){
        anim.setImageResource(R.drawable.derrota1);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                txtsw.setVisibility(View.INVISIBLE);
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
                nextTurn();
            }
        },4500);
    }

    private void animFail1(){
        anim.setImageResource(R.drawable.derrota2);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                txtsw.setVisibility(View.INVISIBLE);
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
                nextTurn();
            }
        },16500);
    }

//Fail animations
//------------------------------------------------------------
    private void animSave(){//random animation
        txtsw.setVisibility(View.VISIBLE);
        txtsw.setImageDrawable(getDrawable(R.drawable.survive));
        Random r=new Random();
        int nr=r.nextInt(2);//this number must be the winning animations you have. To add more increase the number and add the corresponding code in the switch case;

        switch(nr){
            case 0:animSave0();
                break;

            case 1:animSave1();
                break;

            /*case x:animSavex();
              break;
            */
        }
    }

    private void animSave0(){
        anim.setImageResource(R.drawable.save1);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                txtsw.setVisibility(View.INVISIBLE);
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
                nextTurn();
            }
        },2500);
    }

    private void animSave1(){
        anim.setImageResource(R.drawable.save2);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                txtsw.setVisibility(View.INVISIBLE);
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
                nextTurn();
            }
        },4000);
    }
//Fail animations
//------------------------------------------------------------

    private void reloadinganim(){
        Random r=new Random();
        int nr=r.nextInt(2);//this number must be the reload animations you have. To add more increase the number and add the corresponding code in the switch case;

        switch(nr){
            case 0:reloading0();
                break;

            case 1:reloading1();
                break;

            /*case x:Reloadingx();
              break;
            */
        }
    }

    private void reloading0(){
        anim.setImageResource(R.drawable.recarga1);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
            }
        },2000);
    }

    private void reloading1(){
        anim.setImageResource(R.drawable.recarga2);
        anim.setVisibility(View.VISIBLE);

        Handler handler=new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                anim.setVisibility(View.INVISIBLE);
                activatedTouch=true;
            }
        },1600);
    }

}