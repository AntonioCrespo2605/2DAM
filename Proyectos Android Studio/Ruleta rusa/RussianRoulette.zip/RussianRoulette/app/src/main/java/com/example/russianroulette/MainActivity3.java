package com.example.russianroulette;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity3 extends AppCompatActivity {

    int numPlayers, posWinner, difficulty;
    boolean victory;
    GifImageView anim;
    ImageView txtMain;
    Button exit, play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        posWinner=1;
        victory=true;

        anim=findViewById(R.id.anim3);
        txtMain=findViewById(R.id.txtfinal);
        exit=findViewById(R.id.exit2);
        play=findViewById(R.id.play2);

        Bundle b=this.getIntent().getExtras();
        numPlayers=b.getInt("numPlayers");
        victory=b.getBoolean("victory");
        posWinner=b.getInt("posWinner");
        difficulty=b.getInt("difficulty");


        if(numPlayers>1){
            anim.setImageResource(R.drawable.victoria1);
            switch (posWinner){
                case 0:txtMain.setImageDrawable(getDrawable(R.drawable.yw));
                    break;
                case 1:txtMain.setImageDrawable(getDrawable(R.drawable.p1w));
                    break;
                case 2:txtMain.setImageDrawable(getDrawable(R.drawable.p2w));
                    break;
                case 3:txtMain.setImageDrawable(getDrawable(R.drawable.p3w));
                    break;
                //if there are more playes add here more cases
                /*
                case x:
                    break;
                */
            }
        }else{
            if(victory){
                anim.setImageResource(R.drawable.victoria1);
                txtMain.setImageDrawable(getDrawable(R.drawable.yw));
            }else {
                anim.setImageResource(R.drawable.finalderrota);
                txtMain.setImageDrawable(getDrawable(R.drawable.yhd));
            }
        }


        //buttons
        //------------------------------------------------------------------------------------------
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        //achievements
        //------------------------------------------------------------------------------------------

        SharedPreferences prefs=getSharedPreferences("achievements", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor= prefs.edit();
        String ach, ach2;
        if(numPlayers==1){

            if(victory){

                ach=prefs.getString("win1player","not found");
                ach2=prefs.getString("1playermd", "not found");
                if(ach.equals("false") && difficulty<5){
                    editor.putString("win1player","true");
                    Toast msg = new Toast(this);
                    msg.makeText(this, "Achievement unlocked: Winner winner chicken dinner", Toast.LENGTH_SHORT).show();
                    editor.commit();
                }

                if(ach2.equals("false") && difficulty==5){
                    editor.putString("1playermd","true");
                    Toast msg = new Toast(this);
                    msg.makeText(this, "Achievement unlocked: Never tell me the odds", Toast.LENGTH_SHORT).show();
                    editor.commit();
                }

            }else{
                ach=prefs.getString("lose1player","not found");
                if(ach.equals("false")){
                    editor.putString("lose1player","true");
                    Toast msg = new Toast(this);
                    msg.makeText(this, "Achievement unlocked: Highway to Hell", Toast.LENGTH_SHORT).show();
                    editor.commit();
                }
            }

        }else if(numPlayers==2){
            ach=prefs.getString("2player","not found");
            if(ach.equals("false")){
                editor.putString("2player","true");
                Toast msg = new Toast(this);
                msg.makeText(this, "Achievement unlocked: Duel at 12", Toast.LENGTH_SHORT).show();
                editor.commit();
            }
        }else if(numPlayers==3){
            ach=prefs.getString("3player","not found");
            if(ach.equals("false")){
                editor.putString("3player","true");
                Toast msg = new Toast(this);
                msg.makeText(this, "Achievement unlocked: 3´s a croud", Toast.LENGTH_SHORT).show();
                editor.commit();
            }
        }


    }
}