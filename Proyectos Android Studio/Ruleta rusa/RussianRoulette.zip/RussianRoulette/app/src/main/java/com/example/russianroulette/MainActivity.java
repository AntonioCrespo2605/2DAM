package com.example.russianroulette;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {

    int difficulty=1;
    int nplayers=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getSupportActionBar().hide();

        ImageView d1=findViewById(R.id.d1);
        ImageView d2=findViewById(R.id.d2);
        ImageView d3=findViewById(R.id.d3);
        ImageView d4=findViewById(R.id.d4);
        ImageView d5=findViewById(R.id.d5);
        ImageView j1=findViewById(R.id.j1);
        ImageView j2=findViewById(R.id.j2);
        ImageView j3=findViewById(R.id.j3);

        GifImageView anim1=findViewById(R.id.anim1);

        Button exit=findViewById(R.id.exit);
        Button play=findViewById(R.id.play);

        //dificultades
        d1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d2.setImageDrawable(getDrawable(R.drawable.balablanca));
                d3.setImageDrawable(getDrawable(R.drawable.balablanca));
                d4.setImageDrawable(getDrawable(R.drawable.balablanca));
                d5.setImageDrawable(getDrawable(R.drawable.balablanca));
                difficulty=1;
            }
        });

        d2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d2.setImageDrawable(getDrawable(R.drawable.balaroja));
                d3.setImageDrawable(getDrawable(R.drawable.balablanca));
                d4.setImageDrawable(getDrawable(R.drawable.balablanca));
                d5.setImageDrawable(getDrawable(R.drawable.balablanca));
                difficulty=2;
            }
        });

        d3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d2.setImageDrawable(getDrawable(R.drawable.balaroja));
                d3.setImageDrawable(getDrawable(R.drawable.balaroja));
                d4.setImageDrawable(getDrawable(R.drawable.balablanca));
                d5.setImageDrawable(getDrawable(R.drawable.balablanca));
                difficulty=3;
            }
        });

        d4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d2.setImageDrawable(getDrawable(R.drawable.balaroja));
                d3.setImageDrawable(getDrawable(R.drawable.balaroja));
                d4.setImageDrawable(getDrawable(R.drawable.balaroja));
                d5.setImageDrawable(getDrawable(R.drawable.balablanca));
                difficulty=4;
            }
        });

        d5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d2.setImageDrawable(getDrawable(R.drawable.balaroja));
                d3.setImageDrawable(getDrawable(R.drawable.balaroja));
                d4.setImageDrawable(getDrawable(R.drawable.balaroja));
                d5.setImageDrawable(getDrawable(R.drawable.balaroja));
                difficulty=5;
            }
        });
        //----------------------------------------------------

        j1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j2.setImageDrawable(getDrawable(R.drawable.playerempty));
                j3.setImageDrawable(getDrawable(R.drawable.playerempty));
                nplayers=1;
            }
        });

        j2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j2.setImageDrawable(getDrawable(R.drawable.playerfull));
                j3.setImageDrawable(getDrawable(R.drawable.playerempty));
                nplayers=2;
            }
        });

        j3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j2.setImageDrawable(getDrawable(R.drawable.playerfull));
                j3.setImageDrawable(getDrawable(R.drawable.playerfull));
                nplayers=3;
            }
        });

        //----------------------------------------------------
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play.setVisibility(View.INVISIBLE);
                exit.setVisibility(View.INVISIBLE);
                anim1.setVisibility(View.VISIBLE);
                Handler handler=new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("difficulty",difficulty);
                    intent.putExtra("players",nplayers);
                    startActivity(intent);
                    finish();
                    }
                },2300);

            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //achievements settings
        //-----------------------------------------------------

        SharedPreferences prefs=getSharedPreferences("achievements", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor= prefs.edit();

        String ach=prefs.getString("win1player","not found");
        if(ach.equals("not found")){
            editor.putString("win1player","false");
        }

        ach= prefs.getString("lose1player","not found");
        if(ach.equals("not found")){
            editor.putString("lose1player","false");
        }

        ach= prefs.getString("1playermd","not found");
        if(ach.equals("not found")){
            editor.putString("1playermd","false");
        }

        ach= prefs.getString("2player","not found");
        if(ach.equals("not found")){
            editor.putString("2player","false");
        }

        ach= prefs.getString("3player","not found");
        if(ach.equals("not found")){
            editor.putString("3player","false");
        }

        editor.commit();
    }
}