package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class InfoContacto extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_contacto);

        listView=findViewById(R.id.listView2);

        Bundle b=getIntent().getExtras();
        int id=b.getInt("clave");

        /*
        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);
        //SharedPreferences.Editor myEdit = sh.edit();

        String nombre=sh.getString("nombre"+id,"default");
        String apellidos= sh.getString("apellidos"+id,"default");
        String telefono=sh.getString("telefono"+id,"default");
        String email=sh.getString("email"+id,"default");
        String direccion=sh.getString("direccion"+id,"default");
        String observaciones=sh.getString("observaciones"+id,"default");
        String apodo=sh.getString("apodo"+id,"default");
        int dino=sh.getInt("dino"+id,0);*/

        String nombre=b.getString("nombre","default");
        String apellidos= b.getString("apellidos","default");
        String telefono=b.getString("telefono","default");
        String email=b.getString("email","default");
        String direccion=b.getString("direccion","default");
        String observaciones=b.getString("observaciones","default");
        String apodo=b.getString("apodo","default");
        int dino=b.getInt("dino",0);

        String datos[]={nombre+ " "+apellidos, telefono, email, direccion, apodo, observaciones};
        int imagenes[]={R.drawable.usuario,R.drawable.telefono, R.drawable.email, R.drawable.direccion, R.drawable.apodo, R.drawable.observacion};

        InfoContacto.MyAdapter adapter=new InfoContacto.MyAdapter(this, datos, imagenes);
        listView.setAdapter(adapter);

        ImageView iv=findViewById(R.id.perfil);
        iv.setImageResource(dino);
        TextView tv= findViewById(R.id.nombreinfo);
        tv.setText(nombre);
    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String nombres[];
        int dinos[];

        MyAdapter(Context c, String nombres[],int dinos[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.dinos=dinos;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row2, parent, false);

            ImageView im=row.findViewById(R.id.image2);
            TextView nombre=row.findViewById(R.id.nombre2);

            im.setImageResource(dinos[position]);
            nombre.setText(nombres[position]);

            return row;
        }
    }
}