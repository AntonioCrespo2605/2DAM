package com.example.miscontactos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

public class NuevoModificar extends AppCompatActivity {

    EditText nombre, apellidos, telefono, apodo, email, direccion, observaciones;
    int imagenRes;
    ImageView perfil;
    private static final int[]DINOS={R.drawable.anquilo, R.drawable.bronto, R.drawable.estego, R.drawable.parasaurio, R.drawable.ptera, R.drawable.raptor, R.drawable.rex,R.drawable.teri, R.drawable.trike};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_modificar);

        //editTexts
        nombre=findViewById(R.id.editNombre);
        apellidos=findViewById(R.id.editApellidos);
        telefono=findViewById(R.id.editTelefono);
        apodo=findViewById(R.id.editApodo);
        email=findViewById(R.id.editEmail);
        direccion=findViewById(R.id.editDireccion);
        observaciones=findViewById(R.id.editObservaciones);

        //imagen perfil
        perfil=findViewById(R.id.imagenNuevo);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        Bundle b=getIntent().getExtras();
        boolean ediarB=b.getBoolean("editar", false);

        if(ediarB){

        }else{

        }



    }
}