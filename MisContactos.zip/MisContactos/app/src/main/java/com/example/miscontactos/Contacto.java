package com.example.miscontactos;

public class Contacto {
    private String nombre, apellidos, telefono, email, direccion, observaciones, apodo;
    private int id,dino;
    public Contacto(int id, String nombre, String apellidos, String telefono, String email, String direccion, String observaciones, String apodo, int dino){
        this.id=id;
        this.apellidos=apellidos;
        this.nombre=nombre;
        this.telefono=telefono;
        this.email=email;
        this.direccion=direccion;
        this.observaciones=observaciones;
        this.apodo=apodo;
        this.dino=dino;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getApodo() {
        return apodo;
    }

    public void setApodo(String apodo) {
        this.apodo = apodo;
    }

    public int getDino() {
        return dino;
    }

    public void setDino(int dino) {
        this.dino = dino;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Contacto{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", telefono='" + telefono + '\'' +
                ", email='" + email + '\'' +
                ", direccion='" + direccion + '\'' +
                ", observaciones='" + observaciones + '\'' +
                ", apodo='" + apodo + '\'' +
                ", dino=" + dino +
                '}';
    }
}
