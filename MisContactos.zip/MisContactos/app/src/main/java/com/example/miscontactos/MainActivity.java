package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    private static final int[]DINOS={R.drawable.anquilo, R.drawable.bronto, R.drawable.estego, R.drawable.parasaurio, R.drawable.ptera, R.drawable.raptor, R.drawable.rex,R.drawable.teri, R.drawable.trike};

    /**
     * 0-anquilosaurio
     * 1-brontosaurio
     * 2-estegosaurio
     * 3-parasaurio
     * 4-pteranodon
     * 5-raptor
     * 6-rex
     * 7-tericinosaurio
     * 8-triceratops
     * **/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Contacto>contactos=iniciarContactos();

        listView=findViewById(R.id.listView2);

        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getDinos(contactos));
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(MainActivity.this, InfoContacto.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("clave",contactos.get(position).getId());
                intent.putExtra("nombre", contactos.get(position).getNombre());
                intent.putExtra("apellidos", contactos.get(position).getApellidos());
                intent.putExtra("telefono", contactos.get(position).getTelefono());
                intent.putExtra("email", contactos.get(position).getEmail());
                intent.putExtra("direccion", contactos.get(position).getDireccion());
                intent.putExtra("observaciones", contactos.get(position).getObservaciones());
                intent.putExtra("apodo", contactos.get(position).getApodo());
                intent.putExtra("dino", contactos.get(position).getDino());
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    //Adaptador
    class MyAdapter extends ArrayAdapter<String>{
        Context context;
        String nombres[];
        String apodos[];
        int dinos[];

        MyAdapter(Context c, String nombres[], String apodos[],int dinos[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.apodos=apodos;
            this.dinos=dinos;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);

            ImageView dino=row.findViewById(R.id.image);
            TextView nombre=row.findViewById(R.id.nombre);
            TextView apodo=row.findViewById(R.id.apodo);

            dino.setImageResource(dinos[position]);
            nombre.setText(nombres[position]);
            apodo.setText(apodos[position]);

            return row;
        }
    }

    //inicia el arrayList de contactos leyendo de las shared preferences
    private ArrayList<Contacto> iniciarContactos(){
        ArrayList<Contacto>contactos=new ArrayList<Contacto>();

        //para leer y escribir en las shared
        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);

        //recogemos todos los contactos guardados
        int totales=sh.getInt("totales",8);

        //Valores por defecto
        String[]nombsDef={"Antonio","Ivan","Aitana","Xandre","Naila","Yessica","Sergio","Javier"};
        String[]apesDef={"Crespo Gómez", "Cernadas Fragueiro", "Rodríguez Vidal", "Martínez Correia", "Álvarez Suárez", "Rodríguez González","Fernández Rodríguez","Loureiro Pérez"};
        String[]emailsDef={"antonio@gmail.com", "ivan@gmail.com", "aitana@gmail.com","xandre@gmail.com","naila@gmail.com","yessica@gmail.com","sergio@gmail.com","javier@gmail.com"};
        String[]direccionesDef={"cesantes","pousiño","gran vía","moscoso","teis","ponteareas","mercadona(sección de frutas)","cerca de aitana"};
        String[]apodosDef={"Rey Dinosaurio","Bachatosaurio","Tericinosaurio","Macacopitecus","Navajasaurio","Fotosaurio","Nanosaurio","¿Qué?tsal"};
        int[]dinosDef={3,1,7,0,5,2,4,8,6};

        String nombre, apellidos, telefono, email,direccion,observaciones,apodo;
        int id, dino;
        for(int i=0;i<totales;i++){
            if(sh.getBoolean("disponible"+i, true)){
                id=i;
                //los 8 primeros son por defecto
                if(i<8){
                    nombre=sh.getString("nombre"+id,nombsDef[i]);
                    apellidos= sh.getString("apellidos"+id,apesDef[i]);
                    telefono=sh.getString("telefono"+id,i+""+i+""+i+""+i+""+i+""+i+""+i+""+i+""+i);
                    email=sh.getString("email"+id,emailsDef[i]);
                    direccion=sh.getString("direccion"+id,direccionesDef[i]);
                    observaciones=sh.getString("observaciones"+id,"roar");
                    apodo=sh.getString("apodo"+id,apodosDef[i]);
                    dino=sh.getInt("dino"+id,DINOS[dinosDef[i]]);
                }else{
                    //estos son los generados por el usuario
                    nombre=sh.getString("nombre"+id,"default");
                    apellidos= sh.getString("apellidos"+id,"default");
                    telefono=sh.getString("telefono"+id,"default");
                    email=sh.getString("email"+id,"default");
                    direccion=sh.getString("direccion"+id,"default");
                    observaciones=sh.getString("observaciones"+id,"default");
                    apodo=sh.getString("apodo"+id,"default");
                    dino=sh.getInt("dino"+id,0);
                }
                contactos.add(new Contacto(id,nombre,apellidos,telefono,email,direccion,observaciones,apodo,dino));
            }
        }
        return contactos;
        /*notas int
        num=sh.getInt("num",0);
        myEdit.putInt("num", num);
        myEdit.flush()?*/
    }

    //devuelve un array con los nombres de contactos
    private String[]getNombres(ArrayList<Contacto>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getNombre();
        }
        return toret;
    }

    //devuelve un array con las imagenes de cada contacto
    private int []getDinos(ArrayList<Contacto>contactos){
        int toret[]=new int[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getDino();
        }
        return toret;
    }

    //devuelve un array con los apodos de contactos
    private String[]getApodos(ArrayList<Contacto>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getApodo();
        }
        return toret;
    }
}