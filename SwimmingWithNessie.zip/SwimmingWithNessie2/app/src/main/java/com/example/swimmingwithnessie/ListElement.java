package com.example.swimmingwithnessie;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;

public class ListElement {
    private String fecha;
    private int minutos;
    private int segundos;
    private double distanciaMetros;

    public ListElement() {
        this.fecha=fechaActual();
        this.minutos=0;
        this.segundos=0;
        this.distanciaMetros=0;
    }

    public ListElement(String fecha, int minutos, int segundos, double distanciaMetros) {
        this.fecha=fecha;
        this.minutos=minutos;
        this.segundos=segundos;
        this.distanciaMetros=distanciaMetros;
    }

    //getters
    public String getFecha() {
        return fecha;
    }

    public int getMinutos() {
        return minutos;
    }

    public int getSegundos() {
        return segundos;
    }

    public double getDistanciaMetros() {
        return distanciaMetros;
    }

    //setters
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public void setSegundos(int segundos) {
        this.segundos = segundos;
    }

    public void setDistanciaMetros(double distanciaMetros) {
        this.distanciaMetros = distanciaMetros;
    }

    //toString
    @Override
    public String toString() {
        String toret="Fecha: "+this.getFecha()+"\n" +
                "Tiempo: "+this.getMinutos()+":"+this.getSegundos()+"(min:seg)\n" +
                "Distancia"+this.getDistanciaMetros()+"(m)\n" +
                "Velocidad media:"+getVelocidad()+"(km/h)";

        return toret;
    }

    public String datosFecha(){
        return "Tiempo: "+this.getMinutos()+":"+this.getSegundos()+"(min:seg)\n" +
                "Distancia"+this.getDistanciaMetros()+"(m)\n" +
                "Velocidad media:"+getVelocidad()+"(km/h)";
    }

    //returns the currend date
    public String fechaActual(){
        Calendar c1= Calendar.getInstance();
        String toret=Integer.toString(c1.get(Calendar.DATE))+"/"+Integer.toString(c1.get(Calendar.MONTH))+"/"+Integer.toString(c1.get(Calendar.YEAR));
        return toret;
    }

    //it calculates the Sped in km/h
    private double getVelocidad(){
        double km=this.getDistanciaMetros()/1000;
        double h=(this.getMinutos()/60)+(this.getSegundos()/3600);
        double kmh=km/h;
        BigDecimal bd=new BigDecimal(kmh);
        bd=bd.setScale(2, RoundingMode.HALF_UP);
        kmh=bd.doubleValue();

        return kmh;
    }

}
