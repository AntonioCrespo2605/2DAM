package com.example.swimmingwithnessie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    ImageView save;
    EditText nombre, edad, altura, peso;
    TextView t;
    String strNombre="";
    String strEdad="";
    String strAltura="";
    String strPeso="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        save=findViewById(R.id.registrar);
        nombre = findViewById(R.id.fechaEditText);
        edad = findViewById(R.id.distanciaTextEdit);
        altura = findViewById(R.id.minEditText);
        peso = findViewById(R.id.segEditText);
        t=findViewById(R.id.tituloLog);



        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean ok=true;
                strNombre=nombre.getText().toString();
                strEdad=edad.getText().toString();
                strAltura=altura.getText().toString();
                strPeso=peso.getText().toString();

                if(strNombre.isEmpty()) ok=false;
                else if(strEdad.isEmpty())ok=false;
                else if(strAltura.isEmpty())ok=false;
                else if(strPeso.isEmpty())ok=false;

                if(ok){
                    SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = sharedPreferences.edit();
                    myEdit.putBoolean("iniciada", true);
                    myEdit.putString("nombre", strNombre);
                    myEdit.putString("edad", strEdad);
                    myEdit.putString("altura", strAltura);
                    myEdit.putString("peso", strPeso);
                    myEdit.commit();

                    Intent intent = new Intent(Login.this, Vista.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }else{
                    Context context = getApplicationContext();
                    CharSequence text = "Algo tienes mal";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }


            }
        });




    }
}