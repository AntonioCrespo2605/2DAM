package com.example.swimmingwithnessie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Vista extends AppCompatActivity {

    List<ListElement> elements;
    ImageView addButton, salir;
    TextView nombreGuardado, edadGuardada, pesoGuardado, alturaGuardada;
    ArrayList<Integer>numbersDetected;

    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista);

        numbersDetected=new ArrayList<Integer>();
        elements=new ArrayList<>();
        salir=findViewById(R.id.salir);
        nombreGuardado=findViewById(R.id.nombreGuardado);
        edadGuardada=findViewById(R.id.edadGuardada);
        pesoGuardado=findViewById(R.id.pesoGuardado);
        alturaGuardada=findViewById(R.id.alturaGuardada);
        alturaGuardada=findViewById(R.id.alturaGuardada);
        addButton=findViewById(R.id.addImageView);
        addButton.setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
        setInterface();
        init();

        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Vista.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Vista.this, CrearEntrenamiento.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }

    public void setInterface(){

        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String nombre=sh.getString("nombre", "juan");
        String edad=sh.getString("edad", "20");
        String altura= sh.getString("altura","150");
        String peso=sh.getString("peso","55");


        nombreGuardado.setText(nombre);
        edadGuardada.setText(edad);
        alturaGuardada.setText(altura);
        pesoGuardado.setText(peso);

        num=sh.getInt("num",0);

        String fecha, min, seg, dist;

        for (int i=1; i<=num;i++){
            fecha=i+"fecha";
            min=i+"min";
            seg=i+"seg";
            dist=i+"dist";

            String faux=sh.getString(fecha, "nf");
            int maux=Integer.parseInt(sh.getInt(min, -1)+"");
            int saux=Integer.parseInt(sh.getInt(seg, -1)+"");

            Double daux=Double.parseDouble(sh.getString(dist, "-1"));

            if(!faux.equals("nf")){
                elements.add(new ListElement(faux, maux, saux, 0));
                numbersDetected.add(i);
            }
        }
    }

    public void init(){
        /*
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));*/

        ListAdapter listAdapter= new ListAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.listRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }

}