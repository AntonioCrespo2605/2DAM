package com.example.swimmingwithnessie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class Vista extends AppCompatActivity {

    List<ListElement> elements;
    ImageView addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista);

        addButton=findViewById(R.id.addImageView);
        addButton.setColorFilter(Color.parseColor("#000000"), PorterDuff.Mode.SRC_IN);
        init();
    }

    public void init(){
        elements=new ArrayList<>();
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));
        elements.add(new ListElement("15/12/22", 20, 10, 1000));
        elements.add(new ListElement("16/12/22", 22, 34, 1000));
        elements.add(new ListElement("15/12/22", 17, 12, 1000));
        elements.add(new ListElement("15/12/22", 34, 0, 1500));
        elements.add(new ListElement("15/12/22", 10, 59, 500));

        ListAdapter listAdapter= new ListAdapter(elements, this);
        RecyclerView recyclerView = findViewById(R.id.listRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }

}