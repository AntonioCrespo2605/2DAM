package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class Carrusel extends AppCompatActivity {

    ImageView orientacion, foto;
    boolean derecha=true;
    int cont=0;
    final String[]NOMBRES={"estegosaurio", "parasaurio", "pteranodon", "rex", "triceratops"};
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrusel);

        int estego=R.drawable.estego;
        int parasaurio=R.drawable.parasaurio;
        int ptera=R.drawable.ptera;
        int rex=R.drawable.rex;
        int trike=R.drawable.trike;
        int[]imagenes={estego, parasaurio, ptera, rex, trike};


        orientacion=findViewById(R.id.orientacion);
        foto=findViewById(R.id.foto);

        //Al hacer click en las huellas se cambia la orientación y la imagen, además de notificar la nueva dirección
        orientacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(derecha){
                    derecha=false;
                    orientacion.setImageDrawable(getDrawable(R.drawable.huellas_izquierda));
                    Toast.makeText(Carrusel.this, "Orientación cambiada a la izquierda", Toast.LENGTH_SHORT).show();
                }else{
                    derecha=true;
                    orientacion.setImageDrawable(getDrawable(R.drawable.huellas_derecha));
                    Toast.makeText(Carrusel.this, "Orientación cambiada a la derecha", Toast.LENGTH_SHORT).show();
                }
            }
        });


        //evento para cambiar de foto
        foto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //dependiendo del sentido accedemos a una posición distinta del array
                if(derecha)cont++;
                else cont--;

                //si llega a la dimensión del array vuelve a la primera imagen y si llega a la primera se salta a la última
                if(cont==NOMBRES.length)cont=0;
                else if(cont==-1)cont=NOMBRES.length-1;

                foto.setImageDrawable(getDrawable(R.drawable.));

            }
        });




    }
}