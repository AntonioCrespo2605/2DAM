package com.example.swimmingwithnessie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Login extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ArrayList<Entrenamiento> entrenamientos = new ArrayList<>();

        entrenamientos.add(new Entrenamiento("14/12/2022", 30, 25, 1000));
        entrenamientos.add(new Entrenamiento("15/12/2022", 25, 25, 1000));
        entrenamientos.add(new Entrenamiento("16/12/2022", 50, 10, 1100));
    }
}