package com.example.erp.controller;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.erp.dataBaseObjects.Customer;
import com.example.erp.dataBaseObjects.Employee;
import com.example.erp.dataBaseObjects.Product;
import com.example.erp.dataBaseObjects.Sale;
import com.example.erp.dataBaseObjects.Supplie;
import com.example.erp.dataBaseObjects.Supplier;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    //db info
    private static final String DB_NAME="dinosDB.sqlite";
    private static int DB_VERSION=1;

    //table names
    private static final String SUPPLIER_TABLE="supplier";
    private static final String SUPPLIE_TABLE="supplie";
    private static final String PRODUCT_TABLE="product";
    private static final String DINOSAUR_SUPPLIE_TABLE="dinosaur_supplie";
    private static final String SALE_TABLE="sale";
    private static final String PRODUCT_SALE_TABLE="dinosaur_table";
    private static final String EMPLOYEE_TABLE="employee";
    private static final String SALARY_TABLE="salary";
    private static final String CUSTOMER_TABLE="customer";

    //controllers
    private ArrayList<Customer>customers;
    private ArrayList<Employee>employees;
    private ArrayList<Product>products;
    private ArrayList<Supplie>supplies;
    private ArrayList<Supplier>suppliers;
    private ArrayList<Sale>sales;

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create table supplier
        String queryTable="CREATE TABLE "+SUPPLIER_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL, "
                +"address TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table supplie
        queryTable="CREATE TABLE "+SUPPLIE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"id_supplier INTEGER NOT NULL REFERENCES "+SUPPLIER_TABLE+", "
                +"date TEXT NOT NULL, "
                +"state INTEGER NOT NULL,"
                +"shipping_costs TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table dinosaur
        queryTable="CREATE TABLE "+PRODUCT_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"description TEXT NOT NULL,"
                +"stock INTEGER NOT NULL,"
                +"current_price TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table dinosaur_supplier
        queryTable="CREATE TABLE "+DINOSAUR_SUPPLIE_TABLE+" ("
                +"id_dinosaur INTEGER NOT NULL REFERENCES "+PRODUCT_TABLE+", "
                +"id_supplier INTEGER NOT NULL REFERENCES "+SUPPLIE_TABLE+", "
                +"amount INTEGER NOT NULL,"
                +"ind_price TEXT NOT NULL,"
                +"PRIMARY KEY(id_dinosaur, id_supplie));";

        db.execSQL(queryTable);

        //Create table employee
        queryTable="CREATE TABLE "+EMPLOYEE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"dni TEXT NOT NULL,"
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL,"
                +"workstation TEXT NOT NULL,"
                +"bank_number TEXT NOT NULL, "
                +"current_salary TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table salary
        queryTable="CREATE TABLE "+SALARY_TABLE+" ("
                +"date TEXT NOT NULL, "
                +"id_employee INTEGER NOT NULL REFERENCES "+EMPLOYEE_TABLE+", "
                +"salary TEXT NOT NULL, "
                +"PRIMARY KEY(date, id_eployee));";

        db.execSQL(queryTable);

        //Create table customer
        queryTable="CREATE TABLE "+CUSTOMER_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"name TEXT NOT NULL, "
                +"tel TEXT NOT NULL,"
                +"email TEXT NOT NULL);";

        db.execSQL(queryTable);

        //Create table sale
        queryTable="CREATE TABLE "+SALE_TABLE+" ("
                +"id INTEGER PRIMARY KEY, "
                +"date TEXT NOT NULL,"
                +"shipping_costs TEXT NOT NULL, "
                +"state INTEGER NOT NULL,"
                +"id_employee INTEGER NOT NULL REFERENCES "+EMPLOYEE_TABLE+", "
                +"id_customer INTEGER NOT NULL REFERENCES "+CUSTOMER_TABLE+");";

        db.execSQL(queryTable);

        //Create table dinosaur_sale
        queryTable="CREATE TABLE "+PRODUCT_SALE_TABLE+" ("
                +"id_dinosaur INTEGER NOT NULL REFERENCES "+PRODUCT_TABLE+", "
                +"id_sale INTEGER NOT NULL REFERENCES "+SALE_TABLE+", "
                +"amount INTEGER NOT NULL,"
                +"ind_price INTEGER NOT NULL,"
                +"PRIMARY KEY(sale, id_dinosaur));";

        db.execSQL(queryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+PRODUCT_SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SALE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+EMPLOYEE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+CUSTOMER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+DINOSAUR_SUPPLIE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SUPPLIE_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+PRODUCT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS "+SUPPLIER_TABLE);

        onCreate(db);
    }

    /************************************************************************/
    public DBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
        readDB();
    }

    private void readDB(){

    }

    //int id, String name, String tel, String email
    private void readCustomers(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM "+CUSTOMER_TABLE, null);

        if(cursor.moveToFirst()){
            do{
                customers.add(new Customer(cursor.get));
            }while(cursor.moveToNext());
        }
    }
}
