package com.example.erp.dataBaseObjects;

public class Salary {
    private double salary;
    private String fecha;

    public Salary(double salary, String fecha) {
        this.salary = salary;
        this.fecha = fecha;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
