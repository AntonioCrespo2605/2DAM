package pruebas;

import javax.swing.JOptionPane;


public class Main {
    public static void main(String[]args){
        String seleccion = JOptionPane.showInputDialog(
   null,
   "Input dialog",
   JOptionPane.QUESTION_MESSAGE);
        
        System.out.println(seleccion);
        
    }
}
