package libros;

import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//clase Libros
@XmlRootElement(name="libros")
@XmlAccessorType (XmlAccessType.FIELD)
public class Libros {
    @XmlElement(name = "libro")
    private ArrayList<Libro>libros=null;
    
    //getters y setters
    public ArrayList<Libro> getLibros() {
        return libros;
    }

    public void setLibros(ArrayList<Libro> libros) {
        this.libros = libros;
    }
}
